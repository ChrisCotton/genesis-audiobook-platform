import React from 'react';

function QuizzesPage() {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-6">Quizzes</h1>
      
      <div className="bg-white rounded-lg shadow-md p-6">
        <p className="text-lg text-gray-700 mb-4">
          Test your knowledge and understanding of the books you've read with our interactive quizzes.
        </p>
        
        <div className="bg-blue-50 border-l-4 border-blue-500 p-4 mb-6">
          <p className="text-blue-700">
            Quizzes are generated based on your reading materials and adapt to your learning progress.
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 gap-6">
          <div className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow">
            <h3 className="text-xl font-semibold mb-2">Comprehension Quizzes</h3>
            <p className="text-gray-600">Test your understanding of key concepts and plot elements.</p>
          </div>
          
          <div className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow">
            <h3 className="text-xl font-semibold mb-2">Vocabulary Quizzes</h3>
            <p className="text-gray-600">Expand your vocabulary with words from your reading material.</p>
          </div>
          
          <div className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow">
            <h3 className="text-xl font-semibold mb-2">Character Analysis</h3>
            <p className="text-gray-600">Test your knowledge of character motivations and development.</p>
          </div>
          
          <div className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow">
            <h3 className="text-xl font-semibold mb-2">Thematic Quizzes</h3>
            <p className="text-gray-600">Explore the deeper themes and messages in your books.</p>
          </div>
        </div>
        
        <p className="mt-8 text-gray-500 italic">
          Coming soon: Quiz creation and sharing with your book clubs!
        </p>
      </div>
    </div>
  );
}

export default QuizzesPage;