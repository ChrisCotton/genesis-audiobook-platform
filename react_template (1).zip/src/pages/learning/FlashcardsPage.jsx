import React from 'react';

function FlashcardsPage() {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-6">Flashcards</h1>
      
      <div className="bg-white rounded-lg shadow-md p-6">
        <p className="text-lg text-gray-700 mb-4">
          Enhance your learning and memorization with customizable flashcards generated from your reading material.
        </p>
        
        <div className="bg-green-50 border-l-4 border-green-500 p-4 mb-6">
          <p className="text-green-700">
            Flashcards utilize spaced repetition to help you memorize key information more effectively.
          </p>
        </div>
        
        <div className="flex flex-wrap gap-6 mb-8">
          <div className="w-full md:w-1/3 lg:w-1/4 perspective-1000">
            <div className="relative h-48 group">
              <div className="absolute inset-0 bg-blue-100 rounded-lg shadow-md p-4 flex items-center justify-center transform transition-transform duration-500 group-hover:rotate-y-180 backface-hidden">
                <p className="text-xl font-medium text-center">What is the main theme of the book?</p>
              </div>
              <div className="absolute inset-0 bg-yellow-100 rounded-lg shadow-md p-4 flex items-center justify-center transform transition-transform duration-500 rotate-y-180 group-hover:rotate-y-0 backface-hidden">
                <p className="text-lg text-center">The struggle between individual freedom and societal expectations</p>
              </div>
            </div>
          </div>
          
          <div className="w-full md:w-1/3 lg:w-1/4 bg-gray-200 rounded-lg shadow-md p-4 flex items-center justify-center h-48">
            <p className="text-xl text-gray-500 text-center">Create your own flashcards!</p>
          </div>
        </div>
        
        <div className="border-t border-gray-200 pt-6 mt-6">
          <h3 className="text-xl font-semibold mb-4">Features</h3>
          <ul className="list-disc pl-5 space-y-2">
            <li>Auto-generated flashcards from your notes and highlights</li>
            <li>Custom flashcard creation</li>
            <li>Import and export flashcard decks</li>
            <li>Spaced repetition learning system</li>
            <li>Progress tracking</li>
          </ul>
        </div>
      </div>
    </div>
  );
}

export default FlashcardsPage;