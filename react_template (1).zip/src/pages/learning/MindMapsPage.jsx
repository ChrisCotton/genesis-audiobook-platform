import React from 'react';

function MindMapsPage() {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-6">Mind Maps</h1>
      
      <div className="bg-white rounded-lg shadow-md p-6">
        <p className="text-lg text-gray-700 mb-4">
          Visualize concepts, ideas, and connections from your books with interactive mind maps.
        </p>
        
        <div className="bg-purple-50 border-l-4 border-purple-500 p-4 mb-6">
          <p className="text-purple-700">
            Mind maps help organize information visually, making complex ideas easier to understand and remember.
          </p>
        </div>
        
        <div className="relative h-64 md:h-96 border border-gray-200 rounded-lg p-4 mb-8 flex items-center justify-center bg-gray-50">
          <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 bg-blue-500 text-white rounded-full p-3 z-10">
            <span className="text-lg font-medium">Main Concept</span>
          </div>
          
          {/* Simulated mind map branches */}
          <div className="absolute top-1/4 left-1/4 bg-green-500 text-white rounded-full p-2">
            <span>Branch 1</span>
          </div>
          <div className="absolute top-1/3 right-1/4 bg-yellow-500 text-white rounded-full p-2">
            <span>Branch 2</span>
          </div>
          <div className="absolute bottom-1/4 right-1/3 bg-red-500 text-white rounded-full p-2">
            <span>Branch 3</span>
          </div>
          <div className="absolute bottom-1/3 left-1/3 bg-purple-500 text-white rounded-full p-2">
            <span>Branch 4</span>
          </div>
          
          {/* Simulated connecting lines */}
          <svg className="absolute inset-0 w-full h-full" xmlns="http://www.w3.org/2000/svg">
            <line x1="50%" y1="50%" x2="25%" y2="25%" stroke="#4CAF50" strokeWidth="2" />
            <line x1="50%" y1="50%" x2="75%" y2="33%" stroke="#FFC107" strokeWidth="2" />
            <line x1="50%" y1="50%" x2="67%" y2="75%" stroke="#F44336" strokeWidth="2" />
            <line x1="50%" y1="50%" x2="33%" y2="67%" stroke="#9C27B0" strokeWidth="2" />
          </svg>
          
          <p className="text-center text-gray-400">Interactive mind map visualization coming soon</p>
        </div>
        
        <div className="grid md:grid-cols-3 gap-6">
          <div className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow">
            <h3 className="text-xl font-semibold mb-2">AI-Generated Maps</h3>
            <p className="text-gray-600">Get started quickly with AI-generated mind maps based on your readings.</p>
          </div>
          
          <div className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow">
            <h3 className="text-xl font-semibold mb-2">Custom Creation</h3>
            <p className="text-gray-600">Build your own mind maps to organize thoughts and insights.</p>
          </div>
          
          <div className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow">
            <h3 className="text-xl font-semibold mb-2">Collaboration</h3>
            <p className="text-gray-600">Share and collaborate on mind maps with your study groups.</p>
          </div>
        </div>
      </div>
    </div>
  );
}

export default MindMapsPage;