import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { useBook } from '../contexts/BookContext';
import BookCard from '../components/book/BookCard';
import FileUpload from '../components/book/FileUpload';
import TextExtractor from '../components/book/TextExtractor';
import VoiceSelector from '../components/book/VoiceSelector';
import AudioPlayer from '../components/book/AudioPlayer';

function LibraryPage() {
  const { currentUser } = useAuth();
  const { 
    books, 
    loading, 
    addBook, 
    getBook,
    PROCESSING_STATUS, 
    startAudioGeneration,
    updateBookMetadata
  } = useBook();

  const navigate = useNavigate();
  
  // States for UI controls
  const [searchQuery, setSearchQuery] = useState('');
  const [filter, setFilter] = useState('all');
  const [showUploadModal, setShowUploadModal] = useState(false);
  const [showAudioGenerationModal, setShowAudioGenerationModal] = useState(false);
  
  // Book upload states
  const [uploadStep, setUploadStep] = useState(1); // 1: Upload, 2: Metadata, 3: Processing
  const [uploadedBookInfo, setUploadedBookInfo] = useState(null);
  const [uploadError, setUploadError] = useState('');
  const [selectedVoiceId, setSelectedVoiceId] = useState('');
  const [selectedAudioSettings, setSelectedAudioSettings] = useState({});
  const [processingBookId, setProcessingBookId] = useState(null);
  const [bookMetadata, setBookMetadata] = useState({
    title: '',
    author: '',
    description: '',
    totalPages: 0,
    tags: [],
    rawTagInput: ''
  });
  const [extractedContent, setExtractedContent] = useState(null);

  // Redirect to auth if not logged in
  useEffect(() => {
    if (!currentUser && !loading) {
      navigate('/auth');
    }
  }, [currentUser, loading, navigate]);

  // Filter books based on search query and filter
  const filteredBooks = books.filter(book => {
    const matchesSearch = book.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                        book.author.toLowerCase().includes(searchQuery.toLowerCase());
    
    if (filter === 'all') return matchesSearch;
    if (filter === 'in-progress') return matchesSearch && book.progress > 0 && book.progress < 100;
    if (filter === 'completed') return matchesSearch && book.progress === 100;
    if (filter === 'not-started') return matchesSearch && book.progress === 0;
    if (filter === 'with-audio') return matchesSearch && book.hasAudioNarration;
    if (filter === 'without-audio') return matchesSearch && !book.hasAudioNarration;
    
    return matchesSearch;
  });

  // Handle file upload completion
  const handleUploadComplete = useCallback((uploadData) => {
    setUploadedBookInfo(uploadData);
    
    // Set form data from extracted metadata
    if (uploadData.metadata) {
      setBookMetadata({
        title: uploadData.metadata.title || '',
        author: uploadData.metadata.author || '',
        description: '',
        totalPages: uploadData.metadata.totalPages || 0,
        tags: [],
        rawTagInput: ''
      });
    }
    
    // Move to metadata step
    setUploadStep(2);
  }, []);

  // Handle upload error
  const handleUploadError = useCallback((error) => {
    console.error('Upload error:', error);
    setUploadError('There was an error uploading your file. Please try again.');
  }, []);

  // Reset upload modal state
  const resetUploadModal = () => {
    setUploadStep(1);
    setUploadedBookInfo(null);
    setBookMetadata({
      title: '',
      author: '',
      description: '',
      totalPages: 0,
      tags: [],
      rawTagInput: ''
    });
    setUploadError('');
    setProcessingBookId(null);
    setExtractedContent(null);
  };

  // Handle metadata submission
  const handleMetadataSubmit = async (e) => {
    e.preventDefault();
    
    if (!bookMetadata.title || !bookMetadata.author) {
      setUploadError('Please provide at least a title and author for your book.');
      return;
    }
    
    try {
      // Create new book entry with all available file information
      const newBook = await addBook({
        title: bookMetadata.title,
        author: bookMetadata.author,
        description: bookMetadata.description,
        totalPages: bookMetadata.totalPages || 1,
        tags: bookMetadata.tags || [],
        coverImage: uploadedBookInfo?.coverImage || null,
        hasAudioNarration: false,
        audioStatus: PROCESSING_STATUS.PENDING,
        // Pass enhanced file information for more accurate processing
        fileName: uploadedBookInfo?.fileName || null,
        fileFormat: uploadedBookInfo?.fileFormat || null,
        fileSize: uploadedBookInfo?.fileSize || null,
        fileType: uploadedBookInfo?.fileType || null,
        isScreenshot: uploadedBookInfo?.isScreenshot || false,
        estimatedPageCount: uploadedBookInfo?.estimatedPageCount || bookMetadata.totalPages,
        fileSizeMB: uploadedBookInfo?.fileSizeMB || null
      });
      
      setProcessingBookId(newBook.id);
      setUploadStep(3);
    } catch (error) {
      console.error('Error creating book:', error);
      setUploadError('Failed to process book. Please try again.');
    }
  };

  // Handle text extraction completion
  const handleExtractComplete = (extractedData) => {
    setExtractedContent(extractedData);
    setUploadError(''); // Clear any errors on successful extraction
    
    // Update book metadata if we have more accurate information
    if (processingBookId && extractedData) {
      updateBookMetadata(processingBookId, {
        totalPages: extractedData.chapters || bookMetadata.totalPages,
      });
    }
  };

  // Handle audio generation
  const handleGenerateAudio = () => {
    if (!processingBookId || !selectedVoiceId) return;
    
    startAudioGeneration(processingBookId, selectedVoiceId, selectedAudioSettings);
    setShowUploadModal(false);
    resetUploadModal();
  };

  // Handle voice selection
  const handleVoiceSelected = (voiceId, audioSettings) => {
    setSelectedVoiceId(voiceId);
    setSelectedAudioSettings(audioSettings);
  };

  // Handle tag change
  const handleTagChange = (e) => {
    const tagInput = e.target.value;
    setBookMetadata(prev => ({
      ...prev, 
      // Store the raw input value for display in the field
      rawTagInput: tagInput,
      // Parse the tags only when needed for processing
      tags: tagInput.split(',').map(tag => tag.trim()).filter(tag => tag)
    }));
  };

  // Open audio generation modal for existing books
  const openAudioGenerationForBook = (bookId) => {
    setProcessingBookId(bookId);
    setShowAudioGenerationModal(true);
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="w-12 h-12 border-t-4 border-blue-500 border-solid rounded-full animate-spin"></div>
      </div>
    );
  }

  return (
    <div>
      {/* Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6">
        <div>
          <h1 className="text-3xl font-bold text-gray-800">My Library</h1>
          <p className="text-gray-600 mt-1">
            {books.length > 0 
              ? `You have ${books.length} book${books.length > 1 ? 's' : ''} in your library` 
              : 'Your library is empty. Add books to get started.'}
          </p>
        </div>
        <button 
          onClick={() => {
            resetUploadModal();
            setShowUploadModal(true);
          }}
          className="mt-4 md:mt-0 bg-blue-600 hover:bg-blue-700 text-white py-2 px-4 rounded-md transition-colors duration-200 flex items-center"
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" viewBox="0 0 20 20" fill="currentColor">
            <path fillRule="evenodd" d="M10 3a1 1 0 011 1v5h5a1 1 0 110 2h-5v5a1 1 0 11-2 0v-5H4a1 1 0 110-2h5V4a1 1 0 011-1z" clipRule="evenodd" />
          </svg>
          Add New Book
        </button>
      </div>
      
      {/* Search and filters */}
      <div className="bg-white rounded-lg shadow-md p-4 mb-6">
        <div className="flex flex-col md:flex-row md:space-x-4">
          <div className="flex-grow mb-4 md:mb-0">
            <div className="relative">
              <input
                type="text"
                placeholder="Search by title or author..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
              <div className="absolute left-3 top-2.5 text-gray-400">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                  <path fillRule="evenodd" d="M8 4a4 4 0 100 8 4 4 0 000-8zM2 8a6 6 0 1110.89 3.476l4.817 4.817a1 1 0 01-1.414 1.414l-4.816-4.816A6 6 0 012 8z" clipRule="evenodd" />
                </svg>
              </div>
            </div>
          </div>
          <div>
            <select
              value={filter}
              onChange={(e) => setFilter(e.target.value)}
              className="w-full md:w-auto px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="all">All Books</option>
              <option value="in-progress">In Progress</option>
              <option value="completed">Completed</option>
              <option value="not-started">Not Started</option>
              <option value="with-audio">With Audio</option>
              <option value="without-audio">Without Audio</option>
            </select>
          </div>
        </div>
      </div>
      
      {/* Books grid */}
      {filteredBooks.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredBooks.map(book => (
            <div key={book.id} className="relative">
              <BookCard book={book} />
              
              {/* Audio status indicator */}
              {!book.hasAudioNarration && book.audioStatus !== PROCESSING_STATUS.FAILED && (
                <button
                  onClick={() => openAudioGenerationForBook(book.id)}
                  className="absolute top-3 right-3 bg-blue-600 hover:bg-blue-700 text-white rounded-full p-2 shadow-md"
                  title="Generate Audio Narration"
                >
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM9.555 7.168A1 1 0 008 8v4a1 1 0 001.555.832l3-2a1 1 0 000-1.664l-3-2z" clipRule="evenodd" />
                  </svg>
                </button>
              )}
              
              {/* Processing indicator with progress */}
              {(book.audioStatus === PROCESSING_STATUS.EXTRACTING_TEXT || book.audioStatus === PROCESSING_STATUS.GENERATING_AUDIO) && (
                <div className="absolute top-3 right-3 flex items-center space-x-2">
                  <div className="bg-white bg-opacity-90 border border-yellow-400 rounded-md px-2 py-1 text-xs text-gray-700 shadow-md">
                    {book.audioGenerationProgress !== undefined ? (
                      <div className="flex flex-col">
                        <div className="flex items-center">
                          <svg className="animate-spin h-3 w-3 mr-1" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                          </svg>
                          <span>{book.audioGenerationProgress || 0}%</span>
                        </div>
                        <div className="w-full h-1 bg-gray-200 rounded-full mt-1">
                          <div 
                            className="h-1 bg-yellow-400 rounded-full" 
                            style={{ width: `${book.audioGenerationProgress || 0}%` }}
                          ></div>
                        </div>
                      </div>
                    ) : (
                      <div className="flex items-center">
                        <svg className="animate-spin h-3 w-3 mr-1" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                          <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                          <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                        </svg>
                        <span>Processing</span>
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      ) : (
        <div className="bg-white rounded-lg shadow-md p-8 text-center">
          {searchQuery || filter !== 'all' ? (
            <>
              <div className="mx-auto w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mb-4">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-gray-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                </svg>
              </div>
              <h3 className="text-xl font-semibold text-gray-800 mb-2">No matching books found</h3>
              <p className="text-gray-600">Try adjusting your search or filter criteria</p>
            </>
          ) : (
            <>
              <div className="mx-auto w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mb-4">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" />
                </svg>
              </div>
              <h3 className="text-xl font-semibold text-gray-800 mb-2">Your library is empty</h3>
              <p className="text-gray-600 mb-6">
                Add your first book to get started with Genesis
              </p>
              <button 
                onClick={() => {
                  resetUploadModal();
                  setShowUploadModal(true);
                }}
                className="bg-blue-600 hover:bg-blue-700 text-white py-2 px-6 rounded-md transition-colors duration-200"
              >
                Add Your First Book
              </button>
            </>
          )}
        </div>
      )}
      
      {/* Upload modal */}
      {showUploadModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg shadow-xl w-full max-w-3xl">
            <div className="p-6">
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-2xl font-bold text-gray-800">
                  {uploadStep === 1 && 'Upload New Book'}
                  {uploadStep === 2 && 'Book Details'}
                  {uploadStep === 3 && 'Processing Book'}
                </h2>
                <button 
                  onClick={() => {
                    setShowUploadModal(false);
                    resetUploadModal();
                  }}
                  className="text-gray-500 hover:text-gray-700 focus:outline-none"
                >
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                  </svg>
                </button>
              </div>
              
              {/* Progress steps */}
              <div className="mb-8">
                <div className="flex items-center justify-center">
                  <div className={`flex items-center justify-center w-8 h-8 rounded-full ${uploadStep >= 1 ? 'bg-blue-500 text-white' : 'bg-gray-200'}`}>
                    1
                  </div>
                  <div className={`flex-1 h-1 mx-2 ${uploadStep >= 2 ? 'bg-blue-500' : 'bg-gray-200'}`}></div>
                  <div className={`flex items-center justify-center w-8 h-8 rounded-full ${uploadStep >= 2 ? 'bg-blue-500 text-white' : 'bg-gray-200'}`}>
                    2
                  </div>
                  <div className={`flex-1 h-1 mx-2 ${uploadStep >= 3 ? 'bg-blue-500' : 'bg-gray-200'}`}></div>
                  <div className={`flex items-center justify-center w-8 h-8 rounded-full ${uploadStep >= 3 ? 'bg-blue-500 text-white' : 'bg-gray-200'}`}>
                    3
                  </div>
                </div>
                <div className="flex justify-between text-xs text-gray-500 mt-2">
                  <span className="w-8 text-center">Upload</span>
                  <span className="flex-1"></span>
                  <span className="w-8 text-center">Details</span>
                  <span className="flex-1"></span>
                  <span className="w-16 text-center">Processing</span>
                </div>
              </div>
              
              {uploadError && (
                <div className="mb-6 bg-red-50 border-l-4 border-red-500 text-red-700 p-4">
                  <p>{uploadError}</p>
                </div>
              )}
              
              {/* Step 1: File Upload */}
              {uploadStep === 1 && (
                <div>
                  <p className="text-gray-600 mb-6">
                    Upload your book file to add it to your library. We support PDF, EPUB, MOBI, and other formats.
                  </p>
                  
                  <FileUpload 
                    onUploadComplete={handleUploadComplete}
                    onError={handleUploadError}
                  />
                </div>
              )}
              
              {/* Step 2: Metadata */}
              {uploadStep === 2 && (
                <div>
                  <p className="text-gray-600 mb-6">
                    We've extracted some information from your file. Feel free to review and update these details.
                  </p>
                  
                  <form onSubmit={handleMetadataSubmit}>
                    <div className="space-y-4">
                      <div>
                        <label htmlFor="bookTitle" className="block text-sm font-medium text-gray-700 mb-1">
                          Title*
                        </label>
                        <input
                          type="text"
                          id="bookTitle"
                          value={bookMetadata.title}
                          onChange={(e) => setBookMetadata(prev => ({ ...prev, title: e.target.value }))}
                          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                          required
                        />
                      </div>
                      
                      <div>
                        <label htmlFor="bookAuthor" className="block text-sm font-medium text-gray-700 mb-1">
                          Author*
                        </label>
                        <input
                          type="text"
                          id="bookAuthor"
                          value={bookMetadata.author}
                          onChange={(e) => setBookMetadata(prev => ({ ...prev, author: e.target.value }))}
                          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                          required
                        />
                      </div>
                      
                      <div>
                        <label htmlFor="bookDescription" className="block text-sm font-medium text-gray-700 mb-1">
                          Description
                        </label>
                        <textarea
                          id="bookDescription"
                          value={bookMetadata.description}
                          onChange={(e) => setBookMetadata(prev => ({ ...prev, description: e.target.value }))}
                          rows={3}
                          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                        />
                      </div>
                      
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <label htmlFor="bookPages" className="block text-sm font-medium text-gray-700 mb-1">
                            Total Pages
                          </label>
                          <input
                            type="number"
                            id="bookPages"
                            value={bookMetadata.totalPages}
                            onChange={(e) => setBookMetadata(prev => ({ ...prev, totalPages: parseInt(e.target.value) || 0 }))}
                            min="1"
                            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                          />
                        </div>
                        
                        <div>
                          <label htmlFor="bookTags" className="block text-sm font-medium text-gray-700 mb-1">
                            Tags (comma separated)
                          </label>
                          <input
                            type="text"
                            id="bookTags"
                            value={bookMetadata.rawTagInput || ''}
                            onChange={handleTagChange}
                            placeholder="e.g. Fiction, Fantasy, Adventure"
                            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                          />
                        </div>
                      </div>
                    </div>
                    
                    <div className="mt-6 flex justify-end space-x-3">
                      <button
                        type="button"
                        onClick={() => {
                          setUploadStep(1);
                        }}
                        className="px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50"
                      >
                        Back
                      </button>
                      <button
                        type="submit"
                        className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                      >
                        Continue
                      </button>
                    </div>
                  </form>
                </div>
              )}
              
              {/* Step 3: Processing */}
              {uploadStep === 3 && processingBookId && (
                <div>
                  <p className="text-gray-600 mb-6">
                    Your book is being processed. We're extracting the text content and preparing it for audio generation.
                  </p>
                  
                  {/* Text extraction status */}
                  <TextExtractor 
                    bookId={processingBookId}
                    onExtractComplete={handleExtractComplete}
                    onError={(error) => setUploadError(error.message)}
                  />
                  
                  {/* Voice selection */}
                  <div className="mt-6">
                    <h3 className="text-lg font-medium text-gray-900 mb-2">Audio Narration</h3>
                    <p className="text-sm text-gray-600 mb-4">
                      Choose a voice for your audiobook narration. You can preview voices and adjust settings.
                    </p>
                    
                    <VoiceSelector 
                      bookId={processingBookId}
                      onVoiceSelected={handleVoiceSelected}
                    />
                  </div>
                  
                  <div className="mt-6 flex justify-end space-x-3">
                    <button
                      type="button"
                      onClick={() => {
                        setUploadStep(2);
                      }}
                      className="px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50"
                    >
                      Back
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setShowUploadModal(false);
                        resetUploadModal();
                      }}
                      className="px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50"
                    >
                      Skip Audio Generation
                    </button>
                    <button
                      type="button"
                      onClick={handleGenerateAudio}
                      disabled={!selectedVoiceId}
                      className={`px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 ${!selectedVoiceId ? 'opacity-50 cursor-not-allowed' : ''}`}
                    >
                      Generate Audio
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
      
      {/* Audio Generation Modal for Existing Books */}
      {showAudioGenerationModal && processingBookId && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg shadow-xl w-full max-w-lg">
            <div className="p-6">
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-2xl font-bold text-gray-800">Generate Audio Narration</h2>
                <button 
                  onClick={() => {
                    setShowAudioGenerationModal(false);
                    setProcessingBookId(null);
                    setSelectedVoiceId('');
                    setSelectedAudioSettings({});
                  }}
                  className="text-gray-500 hover:text-gray-700 focus:outline-none"
                >
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                  </svg>
                </button>
              </div>
              
              {uploadError && (
                <div className="mb-6 bg-red-50 border-l-4 border-red-500 text-red-700 p-4">
                  <p>{uploadError}</p>
                </div>
              )}
              
              <p className="text-gray-600 mb-6">
                Choose a voice for your audiobook narration. You can preview voices and adjust settings before generation.
              </p>
              
              {/* Show current processing status if the book is being processed */}
              {processingBookId && (
                <div className="mb-6">
                  {(() => {
                    const book = getBook(processingBookId);
                    if (book && book.audioStatus === PROCESSING_STATUS.GENERATING_AUDIO) {
                      return (
                        <div className="bg-yellow-50 border-l-4 border-yellow-500 p-4">
                          <div className="flex">
                            <div className="flex-shrink-0">
                              <svg className="animate-spin h-5 w-5 text-yellow-500" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                              </svg>
                            </div>
                            <div className="ml-3">
                              <p className="text-sm text-yellow-700">
                                {book.audioGenerationStage || 'Processing audio generation'}
                              </p>
                              {book.audioGenerationProgress !== undefined && (
                                <div className="mt-2">
                                  <div className="w-full h-2 bg-gray-200 rounded-full">
                                    <div 
                                      className="h-2 bg-yellow-400 rounded-full transition-all" 
                                      style={{ width: `${book.audioGenerationProgress}%` }}
                                    ></div>
                                  </div>
                                  <p className="text-xs text-gray-500 mt-1 text-right">
                                    {book.audioGenerationProgress}% complete
                                  </p>
                                </div>
                              )}
                            </div>
                          </div>
                        </div>
                      );
                    } else if (book && book.audioStatus === PROCESSING_STATUS.FAILED) {
                      return (
                        <div className="bg-red-50 border-l-4 border-red-500 p-4">
                          <div className="flex">
                            <div className="flex-shrink-0">
                              <svg className="h-5 w-5 text-red-400" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                                <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" />
                              </svg>
                            </div>
                            <div className="ml-3">
                              <p className="text-sm text-red-700">
                                {book.audioGenerationError || 'Failed to generate audio. Please try again.'}
                              </p>
                            </div>
                          </div>
                        </div>
                      );
                    }
                    return null;
                  })()} 
                </div>
              )}
              
              <VoiceSelector 
                bookId={processingBookId}
                onVoiceSelected={handleVoiceSelected}
              />
              
              <div className="mt-6 flex justify-end space-x-3">
                <button
                  type="button"
                  onClick={() => {
                    setShowAudioGenerationModal(false);
                    setProcessingBookId(null);
                  }}
                  className="px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={() => {
                    if (processingBookId && selectedVoiceId) {
                      startAudioGeneration(processingBookId, selectedVoiceId, selectedAudioSettings);
                      setShowAudioGenerationModal(false);
                      setProcessingBookId(null);
                      setSelectedVoiceId('');
                      setSelectedAudioSettings({});
                    }
                  }}
                  disabled={!selectedVoiceId}
                  className={`px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 ${!selectedVoiceId ? 'opacity-50 cursor-not-allowed' : ''}`}
                >
                  Generate Audio
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default LibraryPage;