import React from 'react';

function ExpertsPage() {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-6">Expert Connect</h1>
      
      <div className="bg-white rounded-lg shadow-md p-6">
        <p className="text-lg text-gray-700 mb-4">
          Connect with literary experts, authors, and educators to deepen your understanding and appreciation of literature.
        </p>
        
        <div className="bg-indigo-50 border-l-4 border-indigo-500 p-4 mb-6">
          <p className="text-indigo-700">
            Expert sessions include individual consultations, group discussions, and specialized workshops.
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
          {/* Expert Cards */}
          <div className="border border-gray-200 rounded-lg overflow-hidden hover:shadow-lg transition-shadow">
            <div className="h-48 bg-gray-100 flex items-center justify-center">
              <div className="h-32 w-32 rounded-full bg-indigo-200 flex items-center justify-center text-4xl font-bold text-indigo-600">
                DR
              </div>
            </div>
            <div className="p-4">
              <h3 className="text-xl font-semibold mb-1">Dr. Rebecca Lee</h3>
              <p className="text-gray-500 text-sm mb-2">Literary Criticism | Victorian Literature</p>
              <p className="text-gray-600 mb-3">PhD in English Literature with 15 years teaching experience at Oxford University.</p>
              <div className="flex items-center justify-between">
                <span className="text-sm text-green-600 font-medium">Available for sessions</span>
                <button className="px-3 py-1 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors text-sm">
                  Book Session
                </button>
              </div>
            </div>
          </div>
          
          <div className="border border-gray-200 rounded-lg overflow-hidden hover:shadow-lg transition-shadow">
            <div className="h-48 bg-gray-100 flex items-center justify-center">
              <div className="h-32 w-32 rounded-full bg-amber-200 flex items-center justify-center text-4xl font-bold text-amber-600">
                JM
              </div>
            </div>
            <div className="p-4">
              <h3 className="text-xl font-semibold mb-1">James Morgan</h3>
              <p className="text-gray-500 text-sm mb-2">Author | Creative Writing Coach</p>
              <p className="text-gray-600 mb-3">Award-winning novelist specializing in character development and narrative structure.</p>
              <div className="flex items-center justify-between">
                <span className="text-sm text-green-600 font-medium">Available for workshops</span>
                <button className="px-3 py-1 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors text-sm">
                  Book Workshop
                </button>
              </div>
            </div>
          </div>
          
          <div className="border border-gray-200 rounded-lg overflow-hidden hover:shadow-lg transition-shadow">
            <div className="h-48 bg-gray-100 flex items-center justify-center">
              <div className="h-32 w-32 rounded-full bg-teal-200 flex items-center justify-center text-4xl font-bold text-teal-600">
                SK
              </div>
            </div>
            <div className="p-4">
              <h3 className="text-xl font-semibold mb-1">Dr. Sarah Kim</h3>
              <p className="text-gray-500 text-sm mb-2">Comparative Literature | World Literature</p>
              <p className="text-gray-600 mb-3">Specializes in cross-cultural literary analysis and translation studies.</p>
              <div className="flex items-center justify-between">
                <span className="text-sm text-yellow-600 font-medium">Limited availability</span>
                <button className="px-3 py-1 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors text-sm">
                  Join Waitlist
                </button>
              </div>
            </div>
          </div>
        </div>
        
        <div className="border-t border-gray-200 pt-6">
          <h3 className="text-xl font-semibold mb-4">Session Types</h3>
          <div className="grid md:grid-cols-3 gap-4">
            <div className="border border-gray-200 rounded-lg p-4">
              <h4 className="font-medium text-lg mb-2">One-on-One Consultations</h4>
              <p className="text-gray-600">Personal guidance tailored to your specific questions and interests.</p>
              <p className="mt-2 text-sm text-gray-500">30-60 minutes</p>
            </div>
            
            <div className="border border-gray-200 rounded-lg p-4">
              <h4 className="font-medium text-lg mb-2">Group Discussions</h4>
              <p className="text-gray-600">Engage in rich conversations with experts and fellow readers.</p>
              <p className="mt-2 text-sm text-gray-500">1-2 hours</p>
            </div>
            
            <div className="border border-gray-200 rounded-lg p-4">
              <h4 className="font-medium text-lg mb-2">Writing Workshops</h4>
              <p className="text-gray-600">Improve your writing skills with guidance from published authors.</p>
              <p className="mt-2 text-sm text-gray-500">2-3 hours</p>
            </div>
          </div>
        </div>
        
        <div className="mt-8 flex flex-col md:flex-row items-center justify-between bg-gray-50 p-4 rounded-lg">
          <div>
            <h4 className="font-medium">Become an Expert</h4>
            <p className="text-sm text-gray-600">Share your knowledge and connect with passionate readers.</p>
          </div>
          <button className="mt-3 md:mt-0 px-4 py-2 bg-gray-800 text-white rounded hover:bg-gray-700 transition-colors text-sm">
            Apply as Expert
          </button>
        </div>
      </div>
    </div>
  );
}

export default ExpertsPage;