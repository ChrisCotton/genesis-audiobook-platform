import React from 'react';

function DiscussionsPage() {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-6">Discussions</h1>
      
      <div className="bg-white rounded-lg shadow-md p-6">
        <p className="text-lg text-gray-700 mb-4">
          Join conversations about books, share your thoughts, and learn from the perspectives of other readers.
        </p>
        
        <div className="bg-teal-50 border-l-4 border-teal-500 p-4 mb-6">
          <p className="text-teal-700">
            Our discussion forums are organized by genres, authors, and specific books to help you find relevant conversations.
          </p>
        </div>
        
        <div className="border border-gray-200 rounded-lg divide-y mb-8">
          <div className="p-4 hover:bg-gray-50 transition-colors">
            <div className="flex items-start">
              <div className="flex-shrink-0 mr-4">
                <div className="h-10 w-10 rounded-full bg-blue-100 flex items-center justify-center">
                  <span className="font-medium text-blue-700">JD</span>
                </div>
              </div>
              <div>
                <h3 className="text-lg font-medium mb-1">Symbolism in "The Great Gatsby"</h3>
                <p className="text-gray-600 mb-2">I was struck by the recurring symbols throughout the novel, especially the green light...</p>
                <div className="flex items-center text-sm text-gray-500">
                  <span>Jane Doe</span>
                  <span className="mx-2">•</span>
                  <span>2 hours ago</span>
                  <span className="mx-2">•</span>
                  <span>24 replies</span>
                </div>
              </div>
            </div>
          </div>
          
          <div className="p-4 hover:bg-gray-50 transition-colors">
            <div className="flex items-start">
              <div className="flex-shrink-0 mr-4">
                <div className="h-10 w-10 rounded-full bg-green-100 flex items-center justify-center">
                  <span className="font-medium text-green-700">MS</span>
                </div>
              </div>
              <div>
                <h3 className="text-lg font-medium mb-1">Character development in fantasy series</h3>
                <p className="text-gray-600 mb-2">How do authors maintain character consistency across multi-book series while still allowing for growth?</p>
                <div className="flex items-center text-sm text-gray-500">
                  <span>Mark Smith</span>
                  <span className="mx-2">•</span>
                  <span>1 day ago</span>
                  <span className="mx-2">•</span>
                  <span>42 replies</span>
                </div>
              </div>
            </div>
          </div>
          
          <div className="p-4 hover:bg-gray-50 transition-colors">
            <div className="flex items-start">
              <div className="flex-shrink-0 mr-4">
                <div className="h-10 w-10 rounded-full bg-purple-100 flex items-center justify-center">
                  <span className="font-medium text-purple-700">AL</span>
                </div>
              </div>
              <div>
                <h3 className="text-lg font-medium mb-1">Audiobook narrators: Who's your favorite?</h3>
                <p className="text-gray-600 mb-2">I recently listened to a book with multiple narrators and it completely transformed the experience...</p>
                <div className="flex items-center text-sm text-gray-500">
                  <span>Amy Lee</span>
                  <span className="mx-2">•</span>
                  <span>3 days ago</span>
                  <span className="mx-2">•</span>
                  <span>18 replies</span>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        <div className="flex flex-col md:flex-row gap-6">
          <div className="md:w-1/2">
            <h3 className="text-xl font-semibold mb-3">Popular Topics</h3>
            <div className="flex flex-wrap gap-2">
              <span className="px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-sm">#ClassicLiterature</span>
              <span className="px-3 py-1 bg-green-100 text-green-800 rounded-full text-sm">#SciFi</span>
              <span className="px-3 py-1 bg-purple-100 text-purple-800 rounded-full text-sm">#BookToMovie</span>
              <span className="px-3 py-1 bg-yellow-100 text-yellow-800 rounded-full text-sm">#WritingStyle</span>
              <span className="px-3 py-1 bg-red-100 text-red-800 rounded-full text-sm">#PlotTwists</span>
              <span className="px-3 py-1 bg-teal-100 text-teal-800 rounded-full text-sm">#CharacterArcs</span>
            </div>
          </div>
          
          <div className="md:w-1/2">
            <h3 className="text-xl font-semibold mb-3">Start a Discussion</h3>
            <button className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 transition-colors w-full md:w-auto">
              New Discussion Thread
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default DiscussionsPage;