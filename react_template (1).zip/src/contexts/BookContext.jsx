import React, { createContext, useContext, useState, useEffect } from 'react';
import { useAuth } from './AuthContext';

// Create book context
const BookContext = createContext();

// Custom hook to use book context
export function useBook() {
  return useContext(BookContext);
}

// Processing status enum
export const PROCESSING_STATUS = {
  PENDING: 'pending',
  EXTRACTING_TEXT: 'extracting_text',
  TEXT_EXTRACTED: 'text_extracted',
  GENERATING_AUDIO: 'generating_audio',
  COMPLETED: 'completed',
  FAILED: 'failed'
};

// Available voices
export const AVAILABLE_VOICES = [
  { id: 'v1', name: 'Emma', gender: 'female', accent: 'American' },
  { id: 'v2', name: 'Michael', gender: 'male', accent: 'American' },
  { id: 'v3', name: 'Sophia', gender: 'female', accent: 'British' },
  { id: 'v4', name: 'James', gender: 'male', accent: 'British' },
  { id: 'v5', name: 'Olivia', gender: 'female', accent: 'Australian' }
];

// Mock book data
const MOCK_BOOKS = [
  {
    id: '1',
    title: 'The Innovator\'s Dilemma',
    author: 'Clayton Christensen',
    description: 'A revolutionary business book that has changed corporate America forever.',
    coverImage: '/assets/covers/innovators-dilemma.jpg',
    progress: 35,
    totalPages: 225,
    uploadedBy: '1',
    uploadedAt: new Date(2023, 4, 15).toISOString(),
    lastOpened: new Date(2023, 5, 20).toISOString(),
    hasAudioNarration: true,
    audioStatus: PROCESSING_STATUS.COMPLETED,
    voiceId: 'v2',
    audioSettings: {
      speed: 1.0,
      pitch: 1.0,
      emphasis: 1.0
    },
    tags: ['Business', 'Innovation', 'Technology']
  },
  {
    id: '2',
    title: 'Thinking, Fast and Slow',
    author: 'Daniel Kahneman',
    description: 'The renowned psychologist and winner of the Nobel Prize in Economics explains how we think.',
    coverImage: '/assets/covers/thinking-fast-slow.jpg',
    progress: 15,
    totalPages: 499,
    uploadedBy: '1',
    uploadedAt: new Date(2023, 3, 5).toISOString(),
    lastOpened: new Date(2023, 5, 10).toISOString(),
    hasAudioNarration: true,
    audioStatus: PROCESSING_STATUS.COMPLETED,
    voiceId: 'v1',
    audioSettings: {
      speed: 1.0,
      pitch: 1.0,
      emphasis: 1.0
    },
    tags: ['Psychology', 'Decision Making', 'Behavioral Economics']
  },
  {
    id: '3',
    title: 'Atomic Habits',
    author: 'James Clear',
    description: 'An easy & proven way to build good habits & break bad ones.',
    coverImage: '/assets/covers/atomic-habits.jpg',
    progress: 70,
    totalPages: 320,
    uploadedBy: '1',
    uploadedAt: new Date(2023, 2, 20).toISOString(),
    lastOpened: new Date(2023, 5, 18).toISOString(),
    hasAudioNarration: true,
    audioStatus: PROCESSING_STATUS.COMPLETED,
    voiceId: 'v3',
    audioSettings: {
      speed: 1.2,
      pitch: 1.0,
      emphasis: 1.1
    },
    tags: ['Self Help', 'Productivity', 'Psychology']
  },
  {
    id: '4',
    title: 'The Psychology of Money',
    author: 'Morgan Housel',
    description: 'Timeless lessons on wealth, greed, and happiness.',
    coverImage: '/assets/covers/psychology-money.jpg',
    progress: 0,
    totalPages: 256,
    uploadedBy: '1',
    uploadedAt: new Date(2023, 5, 1).toISOString(),
    lastOpened: null,
    hasAudioNarration: false,
    audioStatus: null,
    tags: ['Finance', 'Psychology', 'Personal Development']
  }
];

// Mock quiz data (user's quizzes for each book)
const MOCK_QUIZZES = [
  {
    id: '1',
    bookId: '1',
    title: 'Chapter 1-3 Quiz',
    completedAt: new Date(2023, 5, 18).toISOString(),
    score: 8,
    totalQuestions: 10
  },
  {
    id: '2',
    bookId: '1',
    title: 'Innovation Concepts Quiz',
    completedAt: new Date(2023, 5, 19).toISOString(),
    score: 7,
    totalQuestions: 10
  },
  {
    id: '3',
    bookId: '3',
    title: 'Habit Formation Basics',
    completedAt: new Date(2023, 5, 20).toISOString(),
    score: 10,
    totalQuestions: 10
  }
];

// Mock annotation data
const MOCK_ANNOTATIONS = [
  {
    id: '1',
    bookId: '1',
    userId: '1',
    content: 'This concept of disruptive innovation is crucial to understand in modern business!',
    pageNumber: 42,
    createdAt: new Date(2023, 5, 16).toISOString(),
    color: 'yellow'
  },
  {
    id: '2',
    bookId: '1',
    userId: '1',
    content: 'Great example of how established companies can miss market shifts.',
    pageNumber: 67,
    createdAt: new Date(2023, 5, 17).toISOString(),
    color: 'green'
  },
  {
    id: '3',
    bookId: '3',
    userId: '1',
    content: 'The 1% improvement concept is revolutionary for building habits.',
    pageNumber: 23,
    createdAt: new Date(2023, 5, 18).toISOString(),
    color: 'blue'
  }
];

// Mock audio segments - using dynamic audio generation for each segment
const MOCK_AUDIO_SEGMENTS = [
  {
    bookId: '1',
    chapterId: '1',
    title: 'Chapter 1: The Growth Imperative',
    // We use a special data URL that contains a short audio clip
    // This is a base64-encoded empty audio file that will work without external files
    url: 'data:audio/mp3;base64,SUQzBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA==',
    duration: 1840, // in seconds
    size: 14.5 // in MB
  },
  {
    bookId: '1',
    chapterId: '2',
    title: 'Chapter 2: Value Networks',
    url: 'data:audio/mp3;base64,SUQzBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA==',
    duration: 2100, // in seconds
    size: 16.2 // in MB
  },
  {
    bookId: '2',
    chapterId: '1',
    title: 'Chapter 1: The Characters of the Story',
    url: 'data:audio/mp3;base64,SUQzBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA==',
    duration: 2340, // in seconds
    size: 18.7 // in MB
  }
];

export function BookProvider({ children }) {
  const { currentUser } = useAuth();
  const [books, setBooks] = useState([]);
  const [userQuizzes, setUserQuizzes] = useState([]);
  const [annotations, setAnnotations] = useState([]);
  const [audioSegments, setAudioSegments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [processingQueue, setProcessingQueue] = useState([]);

  // Load books when user changes
  useEffect(() => {
    const fetchBooks = () => {
      if (currentUser) {
        // Simulate fetch delay
        setTimeout(() => {
          setBooks(MOCK_BOOKS.filter(book => book.uploadedBy === currentUser.id));
          setUserQuizzes(MOCK_QUIZZES);
          setAnnotations(MOCK_ANNOTATIONS.filter(anno => anno.userId === currentUser.id));
          setAudioSegments(MOCK_AUDIO_SEGMENTS);
          setLoading(false);
        }, 800);
      } else {
        setBooks([]);
        setUserQuizzes([]);
        setAnnotations([]);
        setAudioSegments([]);
        setLoading(false);
      }
    };

    fetchBooks();
  }, [currentUser]);

  // Process queue for books that need text extraction or audio generation
  useEffect(() => {
    if (processingQueue.length === 0) return;

    const processQueueItem = async () => {
      const [currentItem, ...remainingItems] = processingQueue;
      const { bookId, process } = currentItem;

      try {
        if (process === 'extract_text') {
          await processBookText(bookId);
        } else if (process === 'generate_audio') {
          await generateBookAudio(bookId);
        }
      } catch (error) {
        console.error(`Error processing ${process} for book ${bookId}:`, error);
        // Update book status to failed
        setBooks(prevBooks => prevBooks.map(book => 
          book.id === bookId ? { ...book, audioStatus: PROCESSING_STATUS.FAILED } : book
        ));
      }

      // Remove processed item from queue
      setProcessingQueue(remainingItems);
    };

    processQueueItem();
  }, [processingQueue]);

  // Get book by ID
  const getBook = (bookId) => {
    return books.find(book => book.id === bookId) || null;
  };

  // Get quizzes for a book
  const getBookQuizzes = (bookId) => {
    return userQuizzes.filter(quiz => quiz.bookId === bookId);
  };

  // Get annotations for a book
  const getBookAnnotations = (bookId) => {
    return annotations.filter(annotation => annotation.bookId === bookId);
  };

  // Get audio segments for a book
  const getBookAudioSegments = (bookId) => {
    return audioSegments.filter(segment => segment.bookId === bookId);
  };

  // Add new book
  const addBook = (bookData) => {
    return new Promise((resolve) => {
      setTimeout(() => {
        const newBook = {
          id: String(Date.now()),
          ...bookData,
          uploadedBy: currentUser.id,
          uploadedAt: new Date().toISOString(),
          lastOpened: null,
          progress: 0,
          hasAudioNarration: false,
          audioStatus: PROCESSING_STATUS.PENDING,
          // Ensure we store file information for more accurate processing
          fileName: bookData.fileName || null,
          fileFormat: bookData.fileFormat || null,
          fileSize: bookData.fileSize || null
        };
        
        setBooks(prevBooks => [...prevBooks, newBook]);
        
        // Add to processing queue for text extraction
        setProcessingQueue(prevQueue => [...prevQueue, { bookId: newBook.id, process: 'extract_text' }]);
        
        resolve(newBook);
      }, 1000);
    });
  };

  // Process book text extraction
  const processBookText = (bookId) => {
    return new Promise((resolve, reject) => {
      // Update status to extracting
      setBooks(prevBooks => prevBooks.map(book => 
        book.id === bookId ? { ...book, audioStatus: PROCESSING_STATUS.EXTRACTING_TEXT } : book
      ));

      // Simulate text extraction process
      setTimeout(() => {
        try {
          // Update book status to text extracted
          setBooks(prevBooks => prevBooks.map(book => 
            book.id === bookId ? { ...book, audioStatus: PROCESSING_STATUS.TEXT_EXTRACTED } : book
          ));
          resolve();
        } catch (error) {
          reject(error);
        }
      }, 3000); // Simulate processing time
    });
  };

  // Generate audio for a book
  const generateBookAudio = (bookId, voiceId = 'v1', audioSettings = { speed: 1.0, pitch: 1.0, emphasis: 1.0 }) => {
    return new Promise((resolve, reject) => {
      const book = getBook(bookId);
      if (!book) {
        reject(new Error(`Book with ID ${bookId} not found`));
        return;
      }

      // Update status to generating audio and initialize progress
      setBooks(prevBooks => prevBooks.map(b => 
        b.id === bookId ? { 
          ...b, 
          audioStatus: PROCESSING_STATUS.GENERATING_AUDIO,
          voiceId,
          audioSettings,
          audioGenerationProgress: 0,
          audioGenerationStage: 'Initializing audio processing'
        } : b
      ));
      
      // Track progress of audio generation with multiple updates to simulate the process
      let progress = 0;
      const totalDuration = 5000; // Total processing time in ms
      const updateInterval = 500; // Update every 500ms
      const progressInterval = setInterval(() => {
        progress += Math.floor(Math.random() * 10) + 5; // Increment by 5-15%
        
        if (progress >= 100) {
          clearInterval(progressInterval);
          progress = 100;
        }
        
        // Update with different status messages at different stages
        setBooks(prevBooks => prevBooks.map(b => 
          b.id === bookId ? { 
            ...b,
            audioGenerationProgress: progress,
            audioGenerationStage: 
              progress < 25 ? 'Analyzing text structure' :
              progress < 50 ? 'Processing voice characteristics' :
              progress < 75 ? 'Generating audio segments' :
              'Finalizing audio narration'
          } : b
        ));
      }, updateInterval);

      // Simulate audio generation process
      setTimeout(() => {
        clearInterval(progressInterval); // Ensure interval is cleared
        
        try {
          // Generate mock audio segments based on book metadata if available
          const chaptersCount = book.chapters || Math.floor(Math.random() * 10) + 3;
          const newSegments = [];
          
          // Generate segments for each chapter
          for (let i = 1; i <= chaptersCount; i++) {
            newSegments.push({
              bookId,
              chapterId: `${bookId}-ch${i}`,
              title: `Chapter ${i}: ${i === 1 ? 'Introduction' : i === chaptersCount ? 'Conclusion' : `Main Concepts ${i}`}`,
              url: `/audio/${bookId}-ch${i}.mp3`,
              duration: Math.floor(Math.random() * 1800) + 900, // 15-45 minutes
              size: parseFloat((Math.random() * 15 + 5).toFixed(1)) // 5-20 MB
            });
          }

          // Add new segments to audio segments
          setAudioSegments(prev => [...prev, ...newSegments]);
          
          // Calculate total audio length
          const totalAudioLength = newSegments.reduce((total, segment) => total + segment.duration, 0);

          // Update book status to completed with additional metadata
          setBooks(prevBooks => prevBooks.map(b => 
            b.id === bookId ? { 
              ...b, 
              audioStatus: PROCESSING_STATUS.COMPLETED,
              hasAudioNarration: true,
              audioGenerationProgress: 100,
              audioGeneratedAt: new Date().toISOString(),
              totalAudioLength: totalAudioLength,
              audioChapters: chaptersCount,
              audioTotalSize: newSegments.reduce((total, segment) => total + segment.size, 0).toFixed(1)
            } : b
          ));

          resolve(newSegments);
        } catch (error) {
          // Update book status to failed
          setBooks(prevBooks => prevBooks.map(b => 
            b.id === bookId ? { 
              ...b, 
              audioStatus: PROCESSING_STATUS.FAILED,
              audioGenerationError: error.message || 'Failed to generate audio narration'
            } : b
          ));
          reject(error);
        }
      }, totalDuration); // Simulate processing time
    });
  };

  // Start audio generation process
  const startAudioGeneration = (bookId, voiceId, audioSettings) => {
    // Add to processing queue
    setProcessingQueue(prevQueue => [...prevQueue, { bookId, process: 'generate_audio', voiceId, audioSettings }]);
  };

  // Update book progress
  const updateBookProgress = (bookId, progress) => {
    return new Promise((resolve) => {
      setTimeout(() => {
        setBooks(prevBooks => prevBooks.map(book => 
          book.id === bookId ? { ...book, progress, lastOpened: new Date().toISOString() } : book
        ));
        
        resolve();
      }, 500);
    });
  };

  // Add annotation
  const addAnnotation = (bookId, content, pageNumber, color = 'yellow') => {
    return new Promise((resolve) => {
      setTimeout(() => {
        const newAnnotation = {
          id: String(Date.now()),
          bookId,
          userId: currentUser.id,
          content,
          pageNumber,
          createdAt: new Date().toISOString(),
          color
        };
        
        setAnnotations(prev => [...prev, newAnnotation]);
        resolve(newAnnotation);
      }, 500);
    });
  };

  // Update book metadata
  const updateBookMetadata = (bookId, metadata) => {
    return new Promise((resolve) => {
      setTimeout(() => {
        setBooks(prevBooks => prevBooks.map(book => 
          book.id === bookId ? { ...book, ...metadata } : book
        ));
        
        resolve();
      }, 500);
    });
  };

  // Get available voices
  const getAvailableVoices = () => {
    return AVAILABLE_VOICES;
  };

  // Context value
  const value = {
    books,
    loading,
    getBook,
    getBookQuizzes,
    getBookAnnotations,
    getBookAudioSegments,
    addBook,
    updateBookProgress,
    addAnnotation,
    updateBookMetadata,
    processBookText,
    generateBookAudio,
    startAudioGeneration,
    getAvailableVoices,
    PROCESSING_STATUS,
    AVAILABLE_VOICES
  };

  return (
    <BookContext.Provider value={value}>
      {children}
    </BookContext.Provider>
  );
}