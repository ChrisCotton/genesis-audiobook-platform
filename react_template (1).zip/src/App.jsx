import { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import Layout from './components/layout/Layout';
import Dashboard from './pages/Dashboard';
import BookView from './pages/BookView';
import LibraryPage from './pages/LibraryPage';
import AuthPage from './pages/AuthPage';
import QuizzesPage from './pages/learning/QuizzesPage';
import FlashcardsPage from './pages/learning/FlashcardsPage';
import MindMapsPage from './pages/learning/MindMapsPage';
import BookClubsPage from './pages/community/BookClubsPage';
import DiscussionsPage from './pages/community/DiscussionsPage';
import ExpertsPage from './pages/community/ExpertsPage';
import { AuthProvider } from './contexts/AuthContext';
import { BookProvider } from './contexts/BookContext';

function App() {
  const [isLoading, setIsLoading] = useState(true);

  // Simulate initial loading
  useEffect(() => {
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 1500);
    
    return () => clearTimeout(timer);
  }, []);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-screen bg-slate-900">
        <div className="text-center">
          <h1 className="text-4xl font-bold text-white mb-4">Genesis</h1>
          <p className="text-xl text-gray-300 mb-8">Interactive Audiobook & Learning Platform</p>
          <div className="w-16 h-16 border-t-4 border-blue-500 border-solid rounded-full animate-spin mx-auto"></div>
        </div>
      </div>
    );
  }

  return (
    <Router>
      <AuthProvider>
        <BookProvider>
          <Routes>
            <Route path="/auth" element={<AuthPage />} />
            <Route path="/" element={<Layout />}>
              <Route index element={<Dashboard />} />
              <Route path="library" element={<LibraryPage />} />
              <Route path="book/:bookId" element={<BookView />} />
              
              {/* Learning routes */}
              <Route path="learning/quizzes" element={<QuizzesPage />} />
              <Route path="learning/flashcards" element={<FlashcardsPage />} />
              <Route path="learning/mindmaps" element={<MindMapsPage />} />
              
              {/* Community routes */}
              <Route path="community/bookclubs" element={<BookClubsPage />} />
              <Route path="community/discussions" element={<DiscussionsPage />} />
              <Route path="community/experts" element={<ExpertsPage />} />
            </Route>
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </BookProvider>
      </AuthProvider>
    </Router>
  );
}

export default App;