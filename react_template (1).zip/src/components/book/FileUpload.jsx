import React, { useState, useCallback } from 'react';
import { useBook } from '../../contexts/BookContext';

const SUPPORTED_FORMATS = {
  PDF: '.pdf',
  EPUB: '.epub',
  TXT: '.txt',
  DOCX: '.docx',
  RTF: '.rtf',
  MOBI: '.mobi',
  AZW: '.azw',
  HTML: '.html',
  MD: '.md',
};

const FileUpload = ({ onUploadComplete, onError }) => {
  const [file, setFile] = useState(null);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [isUploading, setIsUploading] = useState(false);
  const [extractedMetadata, setExtractedMetadata] = useState(null);
  const [uploadedFile, setUploadedFile] = useState(null);
  const [dragActive, setDragActive] = useState(false);
  const [error, setError] = useState('');

  const formatFileSize = (sizeInBytes) => {
    if (sizeInBytes < 1024) {
      return `${sizeInBytes} bytes`;
    } else if (sizeInBytes < 1024 * 1024) {
      return `${(sizeInBytes / 1024).toFixed(2)} KB`;
    } else {
      return `${(sizeInBytes / (1024 * 1024)).toFixed(2)} MB`;
    }
  };

  const isFormatSupported = (fileName) => {
    const extension = `.${fileName.split('.').pop().toLowerCase()}`;
    return Object.values(SUPPORTED_FORMATS).includes(extension);
  };

  const handleDragEnter = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(true);
  };

  const handleDragLeave = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
  };

  const handleDragOver = (e) => {
    e.preventDefault();
    e.stopPropagation();
  };

  const handleDrop = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    
    const files = e.dataTransfer.files;
    if (files && files.length > 0) {
      handleFileSelection(files[0]);
    }
  };

  const handleFileSelection = (selectedFile) => {
    setError('');
    
    if (!selectedFile) {
      setFile(null);
      return;
    }

    // Check file format
    if (!isFormatSupported(selectedFile.name)) {
      setError(`Unsupported file format. Please upload one of: ${Object.values(SUPPORTED_FORMATS).join(', ')}`);
      setFile(null);
      return;
    }
    
    // Display specific file format for better user feedback
    const extension = `.${selectedFile.name.split('.').pop().toLowerCase()}`;
    const formatType = Object.entries(SUPPORTED_FORMATS).find(([_, ext]) => ext === extension)?.[0] || 'Unknown';

    // Check file size (limit to 50MB)
    if (selectedFile.size > 50 * 1024 * 1024) {
      setError('File is too large. Maximum file size is 50MB.');
      setFile(null);
      return;
    }

    setFile(selectedFile);
    
    // Extract basic metadata from filename
    const fileName = selectedFile.name.replace(/\.[^/.]+$/, ''); // Remove extension
    const parts = fileName.split('-').map(part => part.trim());
    
    // Try to extract title and author
    let extractedTitle = parts[0] || fileName;
    let extractedAuthor = parts.length > 1 ? parts[1] : 'Unknown Author';
    
    // Handle case where filename extraction might fail
    if (!extractedTitle) extractedTitle = 'Untitled Book';
    
    // Detect if this is a screenshot and adjust metadata
    const isScreenshot = selectedFile.name.includes('Screen Shot') || 
                        selectedFile.name.includes('Screenshot') || 
                        selectedFile.name.includes('Capture');
    
    // Calculate estimated page count based on file size
    // For screenshots/images: ~15-30 pages per MB depending on content density
    const fileSizeMB = selectedFile.size / (1024 * 1024);
    const estimatedPageCount = isScreenshot ? 
      Math.max(Math.floor(fileSizeMB * 25), 30) : // Screenshots get more pages
      Math.floor(fileSizeMB * 15) + 20; // Other documents

    // Format them to look better (capitalize first letter of each word)
    extractedTitle = extractedTitle
      .split(' ')
      .map(word => word.charAt(0).toUpperCase() + word.slice(1))
      .join(' ');
    
    extractedAuthor = extractedAuthor
      .split(' ')
      .map(word => word.charAt(0).toUpperCase() + word.slice(1))
      .join(' ');

    setExtractedMetadata({
      title: extractedTitle,
      author: extractedAuthor,
      totalPages: estimatedPageCount,
      isScreenshot: isScreenshot,
      fileSizeMB: fileSizeMB
    });
  };

  const uploadFile = useCallback(async () => {
    if (!file) return;
    
    setError('');
    setIsUploading(true);
    setUploadProgress(0);
    
    try {
      // Simulate upload progress
      const progressInterval = setInterval(() => {
        setUploadProgress(prev => {
          const newProgress = prev + Math.random() * 15;
          return newProgress >= 100 ? 100 : newProgress;
        });
      }, 300);
      
      // Simulate network request delay
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      clearInterval(progressInterval);
      setUploadProgress(100);
      
      // Save the uploaded file for later use
      setUploadedFile(file);
      setIsUploading(false);
      
      // Extract file format information
      const extension = `.${file.name.split('.').pop().toLowerCase()}`;
      const formatType = Object.entries(SUPPORTED_FORMATS).find(([_, ext]) => ext === extension)?.[0] || 'Unknown';
      
      // Call onUploadComplete with file and extracted metadata
      onUploadComplete && onUploadComplete({
        file,
        metadata: extractedMetadata,
        fileName: file.name,
        fileFormat: formatType,
        fileSize: file.size,
        fileType: file.type,
        isScreenshot: extractedMetadata.isScreenshot,
        estimatedPageCount: extractedMetadata.totalPages,
        fileSizeMB: extractedMetadata.fileSizeMB
      });
      
    } catch (error) {
      console.error('Error uploading file:', error);
      setError('Failed to upload file. Please try again.');
      onError && onError(error);
      setIsUploading(false);
    }
  }, [file, extractedMetadata, onUploadComplete, onError]);

  return (
    <div className="w-full">
      {error && (
        <div className="mb-4 bg-red-50 border-l-4 border-red-500 p-4">
          <p className="text-red-700">{error}</p>
        </div>
      )}
      
      <div 
        className={`border-2 border-dashed rounded-lg p-6 text-center cursor-pointer
          ${dragActive ? 'border-blue-500 bg-blue-50' : 'border-gray-300 hover:border-blue-400'}
          ${isUploading ? 'opacity-50 pointer-events-none' : ''}`}
        onDragEnter={handleDragEnter}
        onDragLeave={handleDragLeave}
        onDragOver={handleDragOver}
        onDrop={handleDrop}
        onClick={() => !isUploading && document.getElementById('fileInput').click()}
      >
        <input
          id="fileInput"
          type="file"
          className="hidden"
          accept={Object.values(SUPPORTED_FORMATS).join(',')}
          onChange={(e) => handleFileSelection(e.target.files[0])}
          disabled={isUploading}
        />
        
        <div className="flex flex-col items-center justify-center">
          <svg 
            className="w-12 h-12 mb-3 text-gray-400" 
            fill="none" 
            stroke="currentColor" 
            viewBox="0 0 24 24" 
            xmlns="http://www.w3.org/2000/svg"
          >
            <path 
              strokeLinecap="round" 
              strokeLinejoin="round" 
              strokeWidth="2" 
              d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12"
            />
          </svg>
          
          {!file ? (
            <>
              <p className="mb-2 text-sm text-gray-700">
                <span className="font-semibold">Click to upload</span> or drag and drop
              </p>
              <p className="text-xs text-gray-500">
                Supported formats: PDF, EPUB, TXT, DOCX, MOBI
              </p>
            </>
          ) : (
            <>
              <p className="text-sm font-medium text-gray-900">{file.name}</p>
              <p className="text-xs text-gray-500">{formatFileSize(file.size)}</p>
            </>
          )}
        </div>
      </div>

      {isUploading && (
        <div className="mt-4">
          <div className="flex justify-between text-sm text-gray-600 mb-1">
            <span>Uploading...</span>
            <span>{Math.round(uploadProgress)}%</span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2">
            <div 
              className="bg-blue-600 h-2 rounded-full transition-all duration-300" 
              style={{ width: `${uploadProgress}%` }}
            ></div>
          </div>
        </div>
      )}

      {file && !isUploading && !uploadedFile && (
        <div className="mt-4 flex justify-end">
          <button
            onClick={() => setFile(null)}
            className="mr-2 px-4 py-2 text-sm border border-gray-300 rounded-md hover:bg-gray-50"
          >
            Cancel
          </button>
          <button
            onClick={uploadFile}
            className="px-4 py-2 text-sm bg-blue-600 text-white rounded-md hover:bg-blue-700"
          >
            Upload
          </button>
        </div>
      )}

      {uploadedFile && (
        <div className="mt-4 bg-green-50 border-l-4 border-green-500 p-4">
          <div className="flex">
            <div className="flex-shrink-0">
              <svg className="h-5 w-5 text-green-400" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
              </svg>
            </div>
            <div className="ml-3">
              <p className="text-sm text-green-700">
                File uploaded successfully!
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default FileUpload;