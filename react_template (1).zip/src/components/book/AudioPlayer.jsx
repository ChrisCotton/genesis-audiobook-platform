import React, { useState, useEffect, useRef } from 'react';
import { useBook } from '../../contexts/BookContext';

/**
 * AudioPlayer Component
 * 
 * This component provides audio playback functionality for book narration,
 * including controls for play/pause, skip forward/backward, speed adjustment,
 * and chapter navigation.
 */
const AudioPlayer = ({ bookId }) => {
  const { getBook, getBookAudioSegments } = useBook();
  const book = getBook(bookId);
  const audioSegments = getBookAudioSegments(bookId);
  
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentSegmentIndex, setCurrentSegmentIndex] = useState(0);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [playbackRate, setPlaybackRate] = useState(1.0);
  const [volume, setVolume] = useState(0.8);
  const [isLoading, setIsLoading] = useState(true);
  const [showVolumeControl, setShowVolumeControl] = useState(false);
  
  const audioRef = useRef(null);
  const progressBarRef = useRef(null);
  
  // Get current audio segment
  const currentSegment = audioSegments[currentSegmentIndex] || null;
  
  // State for error handling and retry
  const [error, setError] = useState('');
  const [retryCount, setRetryCount] = useState(0);
  const [autoRetryActive, setAutoRetryActive] = useState(false);
  const maxRetries = 3;
  
  // Load audio from URL
  const loadAudio = (url) => {
    if (!url) {
      setError('Audio source not available.');
      setIsLoading(false);
      return;
    }
    
    setIsLoading(true);
    setError('');
    
    const audio = audioRef.current;
    if (!audio) {
      setIsLoading(false);
      setError('Audio player initialization failed.');
      return;
    }
    
    // Reset retry count when intentionally loading a new audio
    setRetryCount(0);
    setAutoRetryActive(false);
    
    // Setup timeout to handle no response from server
    const loadingTimeout = setTimeout(() => {
      if (isLoading) {
        setError('Audio loading timeout. Server might be busy.');
        setIsLoading(false);
      }
    }, 15000); // 15 seconds timeout
    
    // Check if URL is a data URL (our fallback) or a real file path
    const isDataUrl = url.startsWith('data:');
    
    // Add event listener for this specific load operation
    const handleLoadError = () => {
      clearTimeout(loadingTimeout);
      setIsLoading(false);
      
      if (isDataUrl) {
        // For data URLs, try using Web Speech API as a fallback
        provideSpeechSynthesisAudio(currentSegment);
        return;
      }
      
      // If we haven't exceeded max retries, try again automatically
      if (retryCount < maxRetries && !autoRetryActive) {
        setAutoRetryActive(true);
        setError(`Loading audio failed. Retrying automatically (${retryCount + 1}/${maxRetries})...`);
        
        // Exponential backoff for retries (1s, 2s, 4s)
        const retryDelay = Math.pow(2, retryCount) * 1000;
        
        setTimeout(() => {
          setRetryCount(prev => prev + 1);
          setAutoRetryActive(false);
          
          // Try loading again
          audio.src = url;
          audio.load();
          
          if (isPlaying) {
            audio.play().catch(playError => {
              console.error('Failed to play audio after retry:', playError);
              setIsPlaying(false);
            });
          }
        }, retryDelay);
      } else if (retryCount >= maxRetries) {
        // Use speech synthesis as a fallback after max retries
        provideSpeechSynthesisAudio(currentSegment);
      }
    };
    
    // Helper function to use speech synthesis API as fallback
    const provideSpeechSynthesisAudio = (segment) => {
      if (!window.speechSynthesis || !segment) {
        setError('Could not load audio and speech synthesis is not available.');
        return;
      }
      
      // Get the book to access its voice settings
      const thisBook = getBook(bookId);
      const voiceSettings = thisBook?.audioSettings || { speed: 1.0, pitch: 1.0, emphasis: 1.0 };
      
      // Create a synthetic example content based on the chapter title
      const syntheticContent = `This is synthetic audio for ${segment.title}. ` +
        `The real audio file could not be loaded. Please check if the audio server is running.` +
        `In a real implementation, this would be the narration of the chapter content.`;
      
      const utterance = new SpeechSynthesisUtterance(syntheticContent);
      utterance.rate = voiceSettings.speed;
      utterance.pitch = voiceSettings.pitch;
      utterance.volume = 0.8;
      
      // Find a voice that matches the book's voice settings if possible
      if (thisBook?.voiceId) {
        const synVoices = window.speechSynthesis.getVoices();
        if (synVoices.length > 0) {
          const preferredVoice = synVoices.find(v => v.name.toLowerCase().includes('female') ? 
            thisBook.voiceId.includes('v1') || thisBook.voiceId.includes('v3') || thisBook.voiceId.includes('v5') : 
            thisBook.voiceId.includes('v2') || thisBook.voiceId.includes('v4')
          );
          if (preferredVoice) {
            utterance.voice = preferredVoice;
          }
        }
      }
      
      // Update UI
      setIsLoading(false);
      setError('Using speech synthesis as fallback due to audio loading issues.');
      
      // Handle speech events
      utterance.onstart = () => {
        setIsPlaying(true);
      };
      
      utterance.onend = () => {
        setIsPlaying(false);
        // If there are more segments, move to next one
        if (currentSegmentIndex < audioSegments.length - 1 && isPlaying) {
          setCurrentSegmentIndex(prevIndex => prevIndex + 1);
        }
      };
      
      utterance.onerror = (e) => {
        console.error('Speech synthesis error:', e);
        setIsPlaying(false);
        setError('Error during speech synthesis playback.');
      };
      
      // Start or stop based on playing state
      if (isPlaying) {
        window.speechSynthesis.cancel(); // Stop any current speech
        window.speechSynthesis.speak(utterance);
      }
    };
    
    // One-time error handler for this load operation
    const onErrorOnce = (e) => {
      console.error('Audio error during load:', e);
      audio.removeEventListener('error', onErrorOnce);
      handleLoadError();
    };
    
    // If this is a data URL, prepare to use speech synthesis if it fails
    if (isDataUrl) {
      // For data URLs, we know they might not work as real audio files
      audio.addEventListener('error', onErrorOnce);
      audio.src = url;
      audio.load();
      
      setTimeout(() => {
        if (isLoading) {
          // If still loading after a brief delay, use speech synthesis
          handleLoadError();
        }
      }, 1000);
    } else {
      // Regular audio file loading
      audio.addEventListener('error', onErrorOnce);
      audio.src = url;
      audio.load();
    }
    
    // If we want to start playing right away
    if (isPlaying) {
      audio.play().catch(error => {
        console.error('Failed to play audio:', error);
        setIsPlaying(false);
        if (!error.message.includes('user didn\'t interact')) {
          // Only set error if it's not due to autoplay policy
          handleLoadError();
        }
      });
    }
    
    // Clean up the timeout when audio loads successfully
    audio.addEventListener('loadeddata', () => {
      clearTimeout(loadingTimeout);
    }, { once: true });
  };
  
  // Initialize audio player
  useEffect(() => {
    if (!book || !book.hasAudioNarration || audioSegments.length === 0) return;
    
    const audio = audioRef.current;
    if (!audio) return;
    
    // Set up audio event listeners
    const setupAudio = () => {
      audio.addEventListener('loadedmetadata', () => {
        setDuration(audio.duration);
        setIsLoading(false);
      });
      
      audio.addEventListener('timeupdate', () => {
        setCurrentTime(audio.currentTime);
      });
      
      audio.addEventListener('ended', () => {
        if (currentSegmentIndex < audioSegments.length - 1) {
          // Move to next segment
          setCurrentSegmentIndex(prevIndex => prevIndex + 1);
        } else {
          // End of book
          setIsPlaying(false);
        }
      });
      
      audio.addEventListener('error', (e) => {
        console.error('Audio error:', e);
        setIsLoading(false);
        setError(`Unable to play audio: ${e.target.error?.message || 'Unknown error'}`);
      });
    };
    
    // Clean up function
    const cleanupAudio = () => {
      audio.removeEventListener('loadedmetadata', () => {});
      audio.removeEventListener('timeupdate', () => {});
      audio.removeEventListener('ended', () => {});
      audio.removeEventListener('error', () => {});
    };
    
    setupAudio();
    return cleanupAudio;
  }, [book, audioSegments, currentSegmentIndex]);
  
  // Update audio element when segment changes
  useEffect(() => {
    if (!currentSegment) return;
    
    loadAudio(currentSegment.url);
  }, [currentSegment, currentSegmentIndex]);
  
  // Update playback rate when it changes
  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;
    
    audio.playbackRate = playbackRate;
  }, [playbackRate]);
  
  // Update volume when it changes
  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;
    
    audio.volume = volume;
  }, [volume]);
  
  // Play/pause toggle
  const togglePlayPause = () => {
    const audio = audioRef.current;
    if (!audio) return;
    
    if (isPlaying) {
      audio.pause();
    } else {
      audio.play().catch(error => {
        console.error('Failed to play audio:', error);
      });
    }
    
    setIsPlaying(!isPlaying);
  };
  
  // Skip forward/backward
  const skip = (seconds) => {
    const audio = audioRef.current;
    if (!audio) return;
    
    audio.currentTime = Math.max(0, Math.min(audio.currentTime + seconds, audio.duration));
  };
  
  // Change chapter (segment)
  const changeSegment = (index) => {
    if (index >= 0 && index < audioSegments.length) {
      setCurrentSegmentIndex(index);
      setCurrentTime(0);
    }
  };
  
  // Handle progress bar click
  const handleProgressBarClick = (e) => {
    const audio = audioRef.current;
    const progressBar = progressBarRef.current;
    if (!audio || !progressBar) return;
    
    const rect = progressBar.getBoundingClientRect();
    const clickPosition = (e.clientX - rect.left) / rect.width;
    audio.currentTime = clickPosition * audio.duration;
  };
  
  // Format time (seconds) to MM:SS
  const formatTime = (timeInSeconds) => {
    if (isNaN(timeInSeconds)) return '00:00';
    
    const minutes = Math.floor(timeInSeconds / 60);
    const seconds = Math.floor(timeInSeconds % 60);
    return `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
  };
  
  if (!book || !book.hasAudioNarration || audioSegments.length === 0) {
    return (
      <div className="bg-gray-50 rounded-md p-6 text-center">
        <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12 text-gray-400 mx-auto mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" />
        </svg>
        <h3 className="text-lg font-medium text-gray-900 mb-2">Audio Narration Not Available</h3>
        <p className="text-sm text-gray-600">
          This book doesn't have audio narration yet. Generate audio in the book settings.
        </p>
      </div>
    );
  }
  
  return (
    <div className="bg-white rounded-lg border border-gray-200 shadow-sm overflow-hidden">
      {/* Hidden audio element */}
      <audio ref={audioRef} />
      
      {/* Chapter title and progress */}
      <div className="px-4 py-3 bg-gray-50 border-b border-gray-200">
        <div className="flex justify-between items-center">
          <div className="flex-1 mr-2">
            <h3 className="text-sm font-medium text-gray-900 truncate">{currentSegment?.title || 'Loading...'}</h3>
            <p className="text-xs text-gray-500">
              {currentSegmentIndex + 1} of {audioSegments.length} sections
            </p>
          </div>
          
          <div className="flex items-center space-x-3">
            <select 
              value={playbackRate} 
              onChange={(e) => setPlaybackRate(parseFloat(e.target.value))}
              className="text-xs border border-gray-300 rounded py-1 px-2 bg-white focus:outline-none focus:ring-1 focus:ring-blue-500"
            >
              <option value="0.75">0.75x</option>
              <option value="1">1x</option>
              <option value="1.25">1.25x</option>
              <option value="1.5">1.5x</option>
              <option value="1.75">1.75x</option>
              <option value="2">2x</option>
            </select>
            
            <button 
              onClick={() => setShowVolumeControl(!showVolumeControl)}
              className="text-gray-600 hover:text-gray-900 focus:outline-none"
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.536 8.464a5 5 0 010 7.072m2.828-9.9a9 9 0 010 12.728M5.586 15H4a1 1 0 01-1-1v-4a1 1 0 011-1h1.586l4.707-4.707C10.923 3.663 12 4.109 12 5v14c0 .891-1.077 1.337-1.707.707L5.586 15z" />
              </svg>
            </button>
            
            {showVolumeControl && (
              <div className="absolute right-12 top-14 bg-white p-3 rounded-md shadow-lg border border-gray-200">
                <input
                  type="range"
                  min="0"
                  max="1"
                  step="0.01"
                  value={volume}
                  onChange={(e) => setVolume(parseFloat(e.target.value))}
                  className="w-24 h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
                />
              </div>
            )}
          </div>
        </div>
      </div>
      
      {/* Progress bar */}
      <div 
        ref={progressBarRef}
        className="h-1.5 bg-gray-200 relative cursor-pointer"
        onClick={handleProgressBarClick}
      >
        <div 
          className="absolute h-full bg-blue-600 transition-all"
          style={{ width: `${(currentTime / duration) * 100 || 0}%` }}
        ></div>
      </div>
      
      {/* Error message */}
      {error && (
        <div className="p-4 bg-red-50 border border-red-100 rounded-md mx-4 my-2">
          <div className="flex">
            <div className="flex-shrink-0">
              <svg className="h-5 w-5 text-red-400" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" />
              </svg>
            </div>
            <div className="ml-3 flex-grow">
              <p className="text-sm text-red-700">
                {error}
              </p>
              
              {autoRetryActive ? (
                <div className="mt-2 flex items-center">
                  <svg className="animate-spin w-3 h-3 mr-2 text-red-600" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                  </svg>
                  <span className="text-xs text-red-600">Retrying automatically...</span>
                  <button
                    onClick={() => {
                      setAutoRetryActive(false);
                      setError('Auto-retry canceled');
                    }}
                    className="ml-3 text-xs text-gray-500 hover:text-gray-700 underline"
                  >
                    Cancel
                  </button>
                </div>
              ) : (
                <div className="mt-2 flex items-center space-x-3">
                  <button 
                    onClick={() => {
                      setError('');
                      setRetryCount(prev => prev + 1);
                      if (currentSegment) loadAudio(currentSegment.url);
                    }} 
                    disabled={retryCount >= maxRetries}
                    className={`text-xs font-medium flex items-center ${retryCount >= maxRetries ? 'text-gray-400 cursor-not-allowed' : 'text-red-600 hover:text-red-800'}`}
                  >
                    <svg className="w-3 h-3 mr-1" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
                    </svg>
                    {retryCount < maxRetries ? 'Retry Now' : 'Max retries reached'}
                  </button>
                  
                  {retryCount > 0 && retryCount < maxRetries && (
                    <span className="text-xs text-gray-500">{maxRetries - retryCount} {maxRetries - retryCount === 1 ? 'retry' : 'retries'} remaining</span>
                  )}
                </div>
              )}
              
              {retryCount >= maxRetries && (
                <div className="mt-3 p-2 bg-gray-50 rounded border border-gray-200 text-xs text-gray-700">
                  <p className="font-medium mb-1">Unable to load audio. Try these solutions:</p>
                  <ul className="list-disc pl-4 space-y-1">
                    <li>Check your internet connection</li>
                    <li>Refresh the page and try again</li>
                    <li>Try a different browser</li>
                    <li>Audio server might be temporarily unavailable</li>
                  </ul>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
      
      {/* Controls */}
      <div className="px-4 py-3 flex justify-between items-center">
        <div className="text-xs text-gray-500 w-16 text-center">
          {formatTime(currentTime)}
        </div>
        
        <div className="flex items-center space-x-4">
          <button 
            onClick={() => changeSegment(currentSegmentIndex - 1)}
            disabled={currentSegmentIndex === 0}
            className={`focus:outline-none ${currentSegmentIndex === 0 ? 'text-gray-300' : 'text-gray-700 hover:text-gray-900'}`}
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 19l-7-7 7-7m8 14l-7-7 7-7" />
            </svg>
          </button>
          
          <button 
            onClick={() => skip(-10)}
            className="focus:outline-none text-gray-700 hover:text-gray-900"
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12.066 11.2a1 1 0 000 1.6l5.334 4A1 1 0 0019 16V8a1 1 0 00-1.6-.8l-5.334 4zM4.066 11.2a1 1 0 000 1.6l5.334 4A1 1 0 0011 16V8a1 1 0 00-1.6-.8l-5.334 4z" />
            </svg>
          </button>
          
          <button 
            onClick={togglePlayPause}
            className="focus:outline-none bg-blue-600 hover:bg-blue-700 text-white rounded-full w-10 h-10 flex items-center justify-center"
          >
            {isLoading ? (
              <svg className="animate-spin h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
            ) : isPlaying ? (
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 9v6m4-6v6m7-3a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            ) : (
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14.752 11.168l-3.197-2.132A1 1 0 0010 9.87v4.263a1 1 0 001.555.832l3.197-2.132a1 1 0 000-1.664z" />
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            )}
          </button>
          
          <button 
            onClick={() => skip(10)}
            className="focus:outline-none text-gray-700 hover:text-gray-900"
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11.933 12.8a1 1 0 000-1.6L6.6 7.2A1 1 0 005 8v8a1 1 0 001.6.8l5.333-4zM19.933 12.8a1 1 0 000-1.6l-5.333-4A1 1 0 0013 8v8a1 1 0 001.6.8l5.333-4z" />
            </svg>
          </button>
          
          <button 
            onClick={() => changeSegment(currentSegmentIndex + 1)}
            disabled={currentSegmentIndex === audioSegments.length - 1}
            className={`focus:outline-none ${currentSegmentIndex === audioSegments.length - 1 ? 'text-gray-300' : 'text-gray-700 hover:text-gray-900'}`}
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 5l7 7-7 7M5 5l7 7-7 7" />
            </svg>
          </button>
        </div>
        
        <div className="text-xs text-gray-500 w-16 text-center">
          {formatTime(duration)}
        </div>
      </div>
      
      {/* Chapter selection */}
      <div className="border-t border-gray-200 max-h-40 overflow-y-auto">
        {audioSegments.map((segment, index) => (
          <button
            key={segment.chapterId}
            onClick={() => changeSegment(index)}
            className={`w-full text-left px-4 py-3 text-sm transition-colors flex justify-between items-center
              ${currentSegmentIndex === index ? 'bg-blue-50 border-l-4 border-blue-500' : 'hover:bg-gray-50 border-l-4 border-transparent'}`}
          >
            <div className="flex-1 mr-2">
              <p className={`truncate ${currentSegmentIndex === index ? 'font-medium text-blue-800' : 'text-gray-900'}`}>
                {segment.title}
              </p>
              <p className="text-xs text-gray-500">{formatTime(segment.duration)}</p>
            </div>
            
            {currentSegmentIndex === index && isPlaying && (
              <div className="flex-shrink-0">
                <span className="flex h-2.5 w-2.5 relative">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-blue-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-blue-500"></span>
                </span>
              </div>
            )}
          </button>
        ))}
      </div>
    </div>
  );
};

export default AudioPlayer;