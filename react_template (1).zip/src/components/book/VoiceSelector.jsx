import React, { useState, useEffect } from 'react';
import { useBook } from '../../contexts/BookContext';

/**
 * VoiceSelector Component
 * 
 * This component allows users to select a voice for audio narration
 * and adjust audio settings like speed, pitch, and emphasis.
 */
const VoiceSelector = ({ bookId, defaultVoiceId, onVoiceSelected, disabled = false }) => {
  const { getAvailableVoices, getBook } = useBook();
  const [voices, setVoices] = useState([]);
  const [selectedVoiceId, setSelectedVoiceId] = useState(defaultVoiceId || '');
  const [previewPlaying, setPreviewPlaying] = useState(false);
  const [audioSettings, setAudioSettings] = useState({
    speed: 1.0,
    pitch: 1.0,
    emphasis: 1.0
  });
  
  const book = getBook(bookId);
  
  // Load available voices
  useEffect(() => {
    const availableVoices = getAvailableVoices();
    setVoices(availableVoices);
    
    // If no voice is selected and voices are available, select the first one
    if (!selectedVoiceId && availableVoices.length > 0) {
      setSelectedVoiceId(availableVoices[0].id);
    }
    
    // If a book is provided, get its voice settings
    if (book && book.voiceId) {
      setSelectedVoiceId(book.voiceId);
      if (book.audioSettings) {
        setAudioSettings(book.audioSettings);
      }
    }
  }, [getAvailableVoices, selectedVoiceId, book]);
  
  // When voice or settings change, notify parent component
  useEffect(() => {
    if (selectedVoiceId && onVoiceSelected) {
      onVoiceSelected(selectedVoiceId, audioSettings);
    }
  }, [selectedVoiceId, audioSettings, onVoiceSelected]);
  
  // Handle voice selection change
  const handleVoiceChange = (e) => {
    setSelectedVoiceId(e.target.value);
  };
  
  // Handle audio settings change
  const handleSettingChange = (setting, value) => {
    setAudioSettings(prev => ({
      ...prev,
      [setting]: parseFloat(value)
    }));
  };
  
  // State for errors and retry
  const [previewError, setPreviewError] = useState(null);
  const [retryCount, setRetryCount] = useState(0);
  
  // Play voice preview
  const playVoicePreview = () => {
    setPreviewPlaying(true);
    setPreviewError(null);
    
    try {
      // Create an audio element for preview
      const audio = new Audio();
      audio.preload = 'auto';
      
      // Use speech synthesis instead of oscillators
      if (window.speechSynthesis) {
        const utterance = new SpeechSynthesisUtterance('Hello, this is a preview of the selected voice for your audiobook narration.');
        
        // Find a voice that matches the gender/type of our selected voice
        const selectedVoice = voices.find(voice => voice.id === selectedVoiceId);
        if (!selectedVoice) {
          throw new Error('Selected voice not found');
        }
        
        // Apply settings
        utterance.rate = audioSettings.speed;
        utterance.pitch = audioSettings.pitch * 2; // Scale up for better distinction
        utterance.volume = 0.8 + (audioSettings.emphasis - 1.0);
        
        // Apply voice characteristics if browser speech synthesis has voices
        const synVoices = window.speechSynthesis.getVoices();
        // If browser has voices available, try to match our voice with browser voices
        if (synVoices.length > 0) {
          // Try to match based on gender (female/male) and accent
          const matchedVoice = synVoices.find(v => {
            const voiceGender = v.name.toLowerCase().includes('female') ? 'female' : 'male';
            const matchGender = voiceGender === selectedVoice.gender.toLowerCase();
            
            // Try to match accent too if possible
            let matchAccent = false;
            if (selectedVoice.accent === 'American') {
              matchAccent = v.name.includes('US') || v.lang.includes('en-US');
            } else if (selectedVoice.accent === 'British') {
              matchAccent = v.name.includes('UK') || v.lang.includes('en-GB');
            } else if (selectedVoice.accent === 'Australian') {
              matchAccent = v.name.includes('AU') || v.lang.includes('en-AU');
            }
            
            return matchGender && (matchAccent || synVoices.length < 5); // If few voices, match only by gender
          });
          
          if (matchedVoice) {
            utterance.voice = matchedVoice;
          }
        }
        
        // Handle preview completion
        utterance.onend = () => {
          setPreviewPlaying(false);
          setRetryCount(0); // Reset retry count on successful play
        };
        
        utterance.onerror = (error) => {
          console.error('Speech synthesis error:', error);
          setPreviewPlaying(false);
          setPreviewError('Error playing voice preview');
        };
        
        // Speak the utterance
        window.speechSynthesis.cancel(); // Cancel any ongoing speech
        window.speechSynthesis.speak(utterance);
      } else {
        // Fallback to a simple audio tone if speech synthesis is not available
        const audioCtx = new (window.AudioContext || window.webkitAudioContext)();
        const oscillator = audioCtx.createOscillator();
        const gainNode = audioCtx.createGain();
        
        oscillator.type = 'sine';
        oscillator.frequency.value = selectedVoiceId.includes('female') ? 280 : 150;
        gainNode.gain.value = 0.2;
        
        oscillator.connect(gainNode);
        gainNode.connect(audioCtx.destination);
        
        oscillator.start();
        
        // Play a short tone
        setTimeout(() => {
          oscillator.stop();
          setPreviewPlaying(false);
          setRetryCount(0);
        }, 1500);
      }
    } catch (error) {
      console.error('Error playing audio preview:', error);
      setPreviewPlaying(false);
      setPreviewError(error.message || 'Failed to play audio preview');
    }
  };
  
  // Retry preview with a short delay
  const retryPreview = () => {
    setRetryCount(prev => prev + 1);
    setPreviewError(null);
    
    // Add a short delay before retry
    setTimeout(() => {
      playVoicePreview();
    }, 500);
  };
  
  // Find the currently selected voice
  const selectedVoice = voices.find(voice => voice.id === selectedVoiceId);
  
  return (
    <div className="w-full">
      <h3 className="text-lg font-medium text-gray-900 mb-4">Voice Selection</h3>
      
      <div className="mb-6">
        <label htmlFor="voice-select" className="block text-sm font-medium text-gray-700 mb-1">
          Choose a Voice
        </label>
        <div className="flex flex-col md:flex-row md:items-center">
          <div className="flex-grow">
            <select
              id="voice-select"
              value={selectedVoiceId}
              onChange={handleVoiceChange}
              disabled={disabled}
              className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 disabled:bg-gray-100"
            >
              {voices.map(voice => (
                <option key={voice.id} value={voice.id}>
                  {voice.name} ({voice.gender}, {voice.accent})
                </option>
              ))}
            </select>
          </div>
          
          <button
            type="button"
            onClick={playVoicePreview}
            disabled={!selectedVoiceId || previewPlaying || disabled}
            className={`mt-2 md:mt-0 md:ml-2 px-4 py-2 text-sm font-medium text-white rounded-md 
              ${previewPlaying || disabled
                ? 'bg-gray-400 cursor-not-allowed'
                : 'bg-blue-600 hover:bg-blue-700'
              }`}
          >
            {previewPlaying ? (
              <span className="flex items-center">
                <svg className="animate-pulse w-4 h-4 mr-1" viewBox="0 0 24 24" fill="currentColor">
                  <circle cx="12" cy="12" r="10" />
                </svg>
                Playing...
              </span>
            ) : (
              <span className="flex items-center">
                <svg className="w-4 h-4 mr-1" viewBox="0 0 20 20" fill="currentColor">
                  <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM9.555 7.168A1 1 0 008 8v4a1 1 0 001.555.832l3-2a1 1 0 000-1.664l-3-2z" clipRule="evenodd" />
                </svg>
                Preview Voice
              </span>
            )}
          </button>
        </div>
        
        {/* Voice Preview Error Message */}
        {previewError && (
          <div className="mt-2 p-2 bg-red-50 border border-red-100 rounded text-sm text-red-700 flex items-start">
            <svg className="h-5 w-5 text-red-400 flex-shrink-0 mr-1.5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
              <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" />
            </svg>
            <div className="flex-grow">
              <p>{previewError}</p>
              <button 
                onClick={retryPreview}
                disabled={retryCount >= 3}
                className="mt-1 text-xs font-medium text-red-700 hover:text-red-900 inline-flex items-center"
              >
                <svg className="w-3 h-3 mr-1" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
                </svg>
                {retryCount < 3 ? 'Retry Voice Preview' : 'Too many retry attempts'}
              </button>
              {retryCount >= 3 && (
                <p className="text-xs mt-1">
                  Try selecting a different voice or refreshing the page.
                </p>
              )}
            </div>
          </div>
        )}
      </div>
      
      {selectedVoice && (
        <div className="p-4 bg-gray-50 rounded-md mb-6">
          <h4 className="text-sm font-medium text-gray-700 mb-3">Voice Settings</h4>
          
          <div className="space-y-4">
            {/* Speed control */}
            <div>
              <div className="flex items-center justify-between">
                <label htmlFor="speed-control" className="block text-xs font-medium text-gray-600">
                  Speed
                </label>
                <span className="text-xs text-gray-500">{audioSettings.speed.toFixed(1)}x</span>
              </div>
              <input
                id="speed-control"
                type="range"
                min="0.5"
                max="2"
                step="0.1"
                value={audioSettings.speed}
                onChange={(e) => handleSettingChange('speed', e.target.value)}
                disabled={disabled}
                className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer disabled:opacity-50"
              />
              <div className="flex justify-between text-xs text-gray-400">
                <span>0.5x</span>
                <span>1.0x</span>
                <span>2.0x</span>
              </div>
            </div>
            
            {/* Pitch control */}
            <div>
              <div className="flex items-center justify-between">
                <label htmlFor="pitch-control" className="block text-xs font-medium text-gray-600">
                  Pitch
                </label>
                <span className="text-xs text-gray-500">{audioSettings.pitch.toFixed(1)}</span>
              </div>
              <input
                id="pitch-control"
                type="range"
                min="0.8"
                max="1.2"
                step="0.05"
                value={audioSettings.pitch}
                onChange={(e) => handleSettingChange('pitch', e.target.value)}
                disabled={disabled}
                className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer disabled:opacity-50"
              />
              <div className="flex justify-between text-xs text-gray-400">
                <span>Lower</span>
                <span>Normal</span>
                <span>Higher</span>
              </div>
            </div>
            
            {/* Emphasis control */}
            <div>
              <div className="flex items-center justify-between">
                <label htmlFor="emphasis-control" className="block text-xs font-medium text-gray-600">
                  Emphasis
                </label>
                <span className="text-xs text-gray-500">{audioSettings.emphasis.toFixed(1)}</span>
              </div>
              <input
                id="emphasis-control"
                type="range"
                min="0.8"
                max="1.2"
                step="0.05"
                value={audioSettings.emphasis}
                onChange={(e) => handleSettingChange('emphasis', e.target.value)}
                disabled={disabled}
                className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer disabled:opacity-50"
              />
              <div className="flex justify-between text-xs text-gray-400">
                <span>Subtle</span>
                <span>Balanced</span>
                <span>Dramatic</span>
              </div>
            </div>
          </div>
        </div>
      )}
      
      {selectedVoice && (
        <div className="text-xs text-gray-500">
          <p>Selected voice: <span className="font-medium">{selectedVoice.name}</span></p>
          <p>Gender: {selectedVoice.gender}, Accent: {selectedVoice.accent}</p>
        </div>
      )}
    </div>
  );
};

export default VoiceSelector;