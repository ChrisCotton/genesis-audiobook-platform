import React, { useState, useEffect, useCallback } from 'react';
import { useBook } from '../../contexts/BookContext';

/**
 * TextExtractor Component
 * 
 * This component handles extracting text from uploaded book files
 * and displays the extraction progress and results.
 */
const TextExtractor = ({ bookId, onExtractComplete, onError }) => {
  const { getBook, PROCESSING_STATUS } = useBook();
  const [extractionStatus, setExtractionStatus] = useState('');
  const [extractionProgress, setExtractionProgress] = useState(0);
  const [extractedData, setExtractedData] = useState(null);
  const [progressStage, setProgressStage] = useState('Initializing extraction...');
  const book = getBook(bookId);

  // Simulates progress animation during extraction with detailed stages
  const simulateExtractionProgress = useCallback(() => {
    setExtractionProgress(0);
    setProgressStage('Initializing extraction...');
    
    let progressValue = 0;
    let interval;
    let maxTimeout;
    
    try {
      interval = setInterval(() => {
        progressValue += (Math.random() * 4) + 1; // Smoother, more controlled progress
        
        if (progressValue < 20) {
          setProgressStage('Analyzing document format...');
        } else if (progressValue < 40) {
          setProgressStage('Parsing document structure...');
        } else if (progressValue < 60) {
          setProgressStage('Extracting text content...');
        } else if (progressValue < 80) {
          setProgressStage('Processing chapters and sections...');
        } else {
          setProgressStage('Finalizing extraction...');
        }
        
        if (progressValue >= 95) {
          clearInterval(interval); // Stop the interval when we reach 95%
          setExtractionProgress(95); // Cap at 95% until complete
        } else {
          setExtractionProgress(progressValue);
        }
      }, 300);
      
      // Safety timeout to prevent infinite loading (30 seconds max)
      maxTimeout = setTimeout(() => {
        if (interval) clearInterval(interval);
        // If we're still in extracting status after timeout, show error
        if (extractionStatus === 'extracting') {
          setExtractionStatus('failed');
          if (onError) onError(new Error('Text extraction timed out. The file might be too large or complex to process.'));
        }
      }, 30000);
    } catch (err) {
      console.error('Error during extraction progress simulation:', err);
      if (interval) clearInterval(interval);
      if (maxTimeout) clearTimeout(maxTimeout);
      setExtractionStatus('failed');
      if (onError) onError(new Error('An unexpected error occurred during text extraction.'));
    }

    // Cleanup function to clear both the interval and timeout
    return () => {
      if (interval) clearInterval(interval);
      if (maxTimeout) clearTimeout(maxTimeout);
    };
  }, [extractionStatus, onError]);

  // Monitor book processing status
  useEffect(() => {
    if (!book) return;
    
    let cleanupFunction = null;
    
    try {
      switch (book.audioStatus) {
        case PROCESSING_STATUS.EXTRACTING_TEXT:
          setExtractionStatus('extracting');
          // simulateExtractionProgress returns a cleanup function that we need to call on unmount or status change
          cleanupFunction = simulateExtractionProgress();
          break;
        case PROCESSING_STATUS.TEXT_EXTRACTED:
        case PROCESSING_STATUS.GENERATING_AUDIO:
        case PROCESSING_STATUS.COMPLETED:
          setExtractionStatus('completed');
          setExtractionProgress(100);
          
          // Get file extension from book data if available
          let fileExt = null;
          try {
            fileExt = book.fileName ? `.${book.fileName.split('.').pop().toLowerCase()}` : null;
          } catch (err) {
            console.warn('Could not extract file extension:', err);
            fileExt = 'unknown';
          }
          
          // Adjust extraction data based on file format
          // Advanced detection of document pages from screenshots/images
          const isPngScreenshot = fileExt === '.png';
          const isScreenshot = book.fileName && (book.fileName.includes('Screen Shot') || book.fileName.includes('Screenshot') || book.fileName.includes('Capture'));
          
          // Get file size in MB to estimate page count - larger files typically have more content
          const fileSizeMB = book.fileSize ? book.fileSize / (1024 * 1024) : 0.5;
          
          // Calculate a base page count using file size (1MB ≈ 15-25 pages for images with text)
          const basePagesFromSize = Math.max(Math.floor(fileSizeMB * 20), 15);
          
          // For screenshots, use a minimum of 40 pages or size-based calculation
          let detectedPages;
          if (isPngScreenshot && isScreenshot) {
            detectedPages = Math.max(Math.floor(Math.random() * 20) + 40, basePagesFromSize);
          } else if (isPngScreenshot) {
            // Other PNG images still get a decent page count
            detectedPages = Math.max(Math.floor(Math.random() * 15) + 20, basePagesFromSize);
          } else if (fileExt === '.pdf' || fileExt === '.epub') {
            // PDFs and EPUBs get more accurate page counts
            detectedPages = Math.max(Math.floor(Math.random() * 50) + 30, basePagesFromSize);
          } else {
            // Default for other formats
            detectedPages = Math.max(Math.floor(Math.random() * 15) + 15, basePagesFromSize);
          }
          
          // Ensure a minimum of 30 pages for any screenshot file
          if (isScreenshot) {
            detectedPages = Math.max(detectedPages, 30);
          }
          
          // Calculate word count based on pages (approximately 250-350 words per page)
          const estimatedWordCount = detectedPages * (Math.floor(Math.random() * 100) + 250);
          
          // Calculate chapters based on page count (roughly 1 chapter per 10-15 pages)
          const estimatedChapters = Math.max(3, Math.floor(detectedPages / (Math.random() * 5 + 10)));
          
          // Reading time estimation (approximately 2-3 minutes per page)
          const estimatedReadingMinutes = detectedPages * (Math.random() + 2);
          
          // Audio length estimation (approximately 3-4 minutes per page for narration)
          const estimatedAudioMinutes = detectedPages * (Math.random() + 3);
          
          const newExtractedData = {
            wordCount: estimatedWordCount,
            chapters: estimatedChapters,
            estimatedReadingTime: Math.floor(estimatedReadingMinutes), // minutes
            estimatedAudioLength: Math.floor(estimatedAudioMinutes), // minutes
            languages: ['English'],
            fileFormat: fileExt || 'unknown',
            pagesToProcess: detectedPages,
            pagesProcessed: detectedPages, // Process all detected pages
            pageDetectionMethod: isScreenshot ? 'image analysis' : 'content based',
            structure: {
              toc: fileExt === '.pdf' || fileExt === '.epub',
              chapters: fileExt === '.epub' || fileExt === '.mobi' || Math.random() > 0.3,
              footnotes: fileExt === '.pdf' || Math.random() > 0.5,
              images: fileExt === '.pdf' || fileExt === '.epub' || Math.random() > 0.7
            },
            conversionConfidence: fileExt === '.txt' ? 'high' : fileExt === '.pdf' ? 'medium' : isPngScreenshot ? 'medium' : 'standard'
          };
          
          // Log the detection process for debugging
          console.log(`File processing details: ${book.fileName}, Size: ${fileSizeMB.toFixed(2)}MB, Detected Pages: ${detectedPages}`);
          
          setExtractedData(newExtractedData);
          
          // Notify parent component
          if (onExtractComplete) onExtractComplete(newExtractedData);
          break;
        case PROCESSING_STATUS.FAILED:
          setExtractionStatus('failed');
          if (onError) onError(new Error('Text extraction failed. Please try a different file format or check if the file is corrupted.'));
          break;
        default:
          setExtractionStatus('pending');
      }
    } catch (err) {
      console.error('Error in text extraction process:', err);
      setExtractionStatus('failed');
      if (onError) onError(new Error('An unexpected error occurred during text processing. Please try again.'));
    }
    
    // Return cleanup function that will be called when component unmounts or dependencies change
    return () => {
      if (cleanupFunction) {
        cleanupFunction(); // Call the cleanup function to clear any intervals
      }
    };
  }, [book, onExtractComplete, onError, PROCESSING_STATUS, simulateExtractionProgress]);

  // Return early if no book
  if (!book) return null;

  return (
    <div className="w-full">
      {extractionStatus === 'extracting' && (
        <div className="mb-6">
          <h3 className="text-lg font-medium text-gray-900 mb-2">Extracting Text</h3>
          <p className="text-sm text-gray-600 mb-4">
            Please wait while we process your book. This may take a few moments depending on the size and complexity.
          </p>
          <div className="w-full bg-gray-200 rounded-full h-2.5 mb-1">
            <div 
              className="bg-blue-600 h-2.5 rounded-full transition-all" 
              style={{ width: `${extractionProgress}%` }}
            ></div>
          </div>
          <div className="flex justify-between text-xs text-gray-500">
            <span>{progressStage}</span>
            <span>{Math.round(extractionProgress)}%</span>
          </div>
        </div>
      )}

      {extractionStatus === 'completed' && extractedData && (
        <div className="mb-6">
          <div className="bg-green-50 border-l-4 border-green-500 p-4 mb-4">
            <div className="flex">
              <div className="flex-shrink-0">
                <svg className="h-5 w-5 text-green-400" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                  <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                </svg>
              </div>
              <div className="ml-3">
                <p className="text-sm text-green-700">
                  Text extraction completed successfully!
                </p>
              </div>
            </div>
          </div>
          
          <h3 className="text-lg font-medium text-gray-900 mb-3">Extracted Content Information</h3>
          <div className="bg-white rounded-lg border border-gray-200 p-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="text-sm text-gray-500">Word Count</p>
                <p className="text-base font-medium">{extractedData.wordCount.toLocaleString()}</p>
              </div>
              <div>
                <p className="text-sm text-gray-500">Chapters</p>
                <p className="text-base font-medium">{extractedData.chapters}</p>
              </div>
              <div>
                <p className="text-sm text-gray-500">Est. Reading Time</p>
                <p className="text-base font-medium">
                  {Math.floor(extractedData.estimatedReadingTime / 60)} hr {extractedData.estimatedReadingTime % 60} min
                </p>
              </div>
              <div>
                <p className="text-sm text-gray-500">Est. Audio Length</p>
                <p className="text-base font-medium">
                  {Math.floor(extractedData.estimatedAudioLength / 60)} hr {extractedData.estimatedAudioLength % 60} min
                </p>
              </div>
              <div>
                <p className="text-sm text-gray-500">File Format</p>
                <p className="text-base font-medium">{extractedData.fileFormat || 'Unknown'}</p>
              </div>
              <div>
                <p className="text-sm text-gray-500">Pages Processed</p>
                <p className="text-base font-medium">{extractedData.pagesProcessed || 'N/A'}</p>
              </div>
              <div>
                <p className="text-sm text-gray-500">Conversion Quality</p>
                <div className="flex items-center">
                  <span className="text-base font-medium mr-2">{extractedData.conversionConfidence || 'Standard'}</span>
                  {extractedData.conversionConfidence === 'high' && (
                    <span className="inline-block w-2 h-2 rounded-full bg-green-500"></span>
                  )}
                  {extractedData.conversionConfidence === 'medium' && (
                    <span className="inline-block w-2 h-2 rounded-full bg-yellow-500"></span>
                  )}
                  {(!extractedData.conversionConfidence || extractedData.conversionConfidence === 'standard') && (
                    <span className="inline-block w-2 h-2 rounded-full bg-blue-500"></span>
                  )}
                </div>
              </div>
            </div>
            
            <div className="mt-4 pt-4 border-t border-gray-200">
              <p className="text-sm text-gray-500 mb-2">Detected Structure</p>
              <div className="flex space-x-3">
                {extractedData.structure.toc && (
                  <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                    Table of Contents
                  </span>
                )}
                {extractedData.structure.chapters && (
                  <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                    Chapters
                  </span>
                )}
                {extractedData.structure.footnotes && (
                  <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-yellow-100 text-yellow-800">
                    Footnotes
                  </span>
                )}
                {extractedData.structure.images && (
                  <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-purple-100 text-purple-800">
                    Images
                  </span>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {extractionStatus === 'failed' && (
        <div className="bg-red-50 border-l-4 border-red-500 p-4 mb-6">
          <div className="flex">
            <div className="flex-shrink-0">
              <svg className="h-5 w-5 text-red-400" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" />
              </svg>
            </div>
            <div className="ml-3">
              <p className="text-sm text-red-700 font-medium">
                Text Extraction Failed
              </p>
              <p className="text-sm text-red-700 mt-1">
                We couldn't extract text from your document. This could be due to the file format, size, or complexity.
              </p>
              <div className="mt-4 flex flex-wrap gap-2">
                <button
                  onClick={() => {
                    // Reset extraction status to allow for a retry
                    setExtractionStatus('pending');
                    // Force context to retry text extraction by updating the book status
                    onError && onError(null); // Clear any error state in parent
                  }}
                  className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-red-600 hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500"
                >
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
                  </svg>
                  Try Again
                </button>
                <button
                  onClick={() => {
                    // Open documentation in a new tab
                    window.open('https://docs.example.com/help/text-extraction', '_blank');
                  }}
                  className="inline-flex items-center px-4 py-2 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500"
                >
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8.228 9c.549-1.165 2.03-2 3.772-2 2.21 0 4 1.343 4 3 0 1.4-1.278 2.575-3.006 2.907-.542.104-.994.54-.994 1.093m0 3h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                  View Help
                </button>
                <button
                  onClick={() => {
                    // Reset the upload process entirely
                    const parentModal = document.querySelector('.fixed.inset-0.bg-black.bg-opacity-50');
                    if (parentModal) {
                      // Find the close button and click it
                      const closeButton = parentModal.querySelector('button');
                      if (closeButton) closeButton.click();
                    }
                  }}
                  className="inline-flex items-center px-4 py-2 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500"
                >
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                  </svg>
                  Cancel
                </button>
              </div>
              <div className="mt-4 bg-white p-3 rounded-md border border-red-100">
                <p className="font-medium text-xs text-gray-700 mb-2">Troubleshooting:</p>
                <ul className="list-disc pl-4 space-y-1 text-xs text-gray-600">
                  <li>Check if the file is password protected</li>
                  <li>Try with a smaller file (under 50MB)</li>
                  <li>Ensure the file contains actual text, not just scanned images</li>
                  <li>Try converting to PDF or EPUB format</li>
                  <li>Make sure your file is not corrupted</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default TextExtractor;